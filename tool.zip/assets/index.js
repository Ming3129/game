var Xe=Object.defineProperty,Ye=Object.defineProperties;var Ue=Object.getOwnPropertyDescriptors;var Rt=Object.getOwnPropertySymbols;var be=Object.prototype.hasOwnProperty,he=Object.prototype.propertyIsEnumerable;var fe=(t,e,n)=>e in t?Xe(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n,et=(t,e)=>{for(var n in e||(e={}))be.call(e,n)&&fe(t,n,e[n]);if(Rt)for(var n of Rt(e))he.call(e,n)&&fe(t,n,e[n]);return t},pt=(t,e)=>Ye(t,Ue(e));var ve=(t,e)=>{var n={};for(var a in t)be.call(t,a)&&e.indexOf(a)<0&&(n[a]=t[a]);if(t!=null&&Rt)for(var a of Rt(t))e.indexOf(a)<0&&he.call(t,a)&&(n[a]=t[a]);return n};var Et=(t,e,n)=>new Promise((a,s)=>{var c=d=>{try{r(n.next(d))}catch(l){s(l)}},i=d=>{try{r(n.throw(d))}catch(l){s(l)}},r=d=>d.done?a(d.value):Promise.resolve(d.value).then(c,i);r((n=n.apply(t,e)).next())});const J={common:{key:"common",name:"普通",color:"#2b5285",restock:10,bonus:0,unitPrice:1},rare:{key:"rare",name:"稀有",color:"#3c7834",restock:5,bonus:12,unitPrice:5},epic:{key:"epic",name:"史诗",color:"#603872",restock:2,bonus:30,unitPrice:15},legendary:{key:"legendary",name:"传说",color:"#a46206",restock:1,bonus:80,unitPrice:30},limited:{key:"limited",name:"限定",color:"#9f130a",restock:0,bonus:0,unitPrice:0}},X={ring:{key:"ring",name:"戒指"},necklace:{key:"necklace",name:"项链"},bracelet:{key:"bracelet",name:"手链"},earring:{key:"earring",name:"耳环"}},lt=Object.keys(X),H=[{id:"ring_c1",cat:"ring",rarity:"common",name:"素圈银戒"},{id:"ring_c2",cat:"ring",rarity:"common",name:"宽版银戒"},{id:"ring_c3",cat:"ring",rarity:"common",name:"扭纹银戒"},{id:"ring_c4",cat:"ring",rarity:"common",name:"磨砂银戒"},{id:"ring_c5",cat:"ring",rarity:"common",name:"小钻素戒"},{id:"ring_c6",cat:"ring",rarity:"common",name:"贝母方戒"},{id:"ring_c7",cat:"ring",rarity:"common",name:"小猫银戒"},{id:"ring_c8",cat:"ring",rarity:"common",name:"糖纸银戒"},{id:"ring_c9",cat:"ring",rarity:"common",name:"莫比乌斯环"},{id:"ring_c10",cat:"ring",rarity:"common",name:"蝴蝶结银戒"},{id:"ring_c11",cat:"ring",rarity:"common",name:"星星银戒"},{id:"ring_r1",cat:"ring",rarity:"rare",name:"月光石戒"},{id:"ring_r2",cat:"ring",rarity:"rare",name:"藤蔓缠指"},{id:"ring_r3",cat:"ring",rarity:"rare",name:"拉丝蝴蝶"},{id:"ring_r4",cat:"ring",rarity:"rare",name:"满钻排戒"},{id:"ring_r5",cat:"ring",rarity:"rare",name:"珍珠银戒"},{id:"ring_r6",cat:"ring",rarity:"rare",name:"椭圆宝石戒"},{id:"ring_r7",cat:"ring",rarity:"rare",name:"方形宝石戒"},{id:"ring_r8",cat:"ring",rarity:"rare",name:"红玫瑰银戒"},{id:"ring_e1",cat:"ring",rarity:"epic",name:"海棠凝露"},{id:"ring_e2",cat:"ring",rarity:"epic",name:"月桂缠枝"},{id:"ring_e3",cat:"ring",rarity:"epic",name:"蔷薇荆棘"},{id:"ring_e4",cat:"ring",rarity:"epic",name:"星轨密镶"},{id:"ring_l1",cat:"ring",rarity:"legendary",name:"泪滴蓝宝"},{id:"ring_l2",cat:"ring",rarity:"legendary",name:"凰羽鎏金"},{id:"ring_x1",cat:"ring",rarity:"limited",name:"绯樱魔晶戒"},{id:"nck_c1",cat:"necklace",rarity:"common",name:"珍珠锁骨链"},{id:"nck_c2",cat:"necklace",rarity:"common",name:"细银十字链"},{id:"nck_c3",cat:"necklace",rarity:"common",name:"细银圆链"},{id:"nck_c4",cat:"necklace",rarity:"common",name:"简约蛇骨链"},{id:"nck_c5",cat:"necklace",rarity:"common",name:"双层细链"},{id:"nck_c6",cat:"necklace",rarity:"common",name:"小月牙银链"},{id:"nck_c7",cat:"necklace",rarity:"common",name:"细珠叠链"},{id:"nck_c8",cat:"necklace",rarity:"common",name:"小星星银链"},{id:"nck_c9",cat:"necklace",rarity:"common",name:"心形细链"},{id:"nck_c10",cat:"necklace",rarity:"common",name:"水滴银坠链"},{id:"nck_c11",cat:"necklace",rarity:"common",name:"小金珠链"},{id:"nck_r1",cat:"necklace",rarity:"rare",name:"海蓝泪坠"},{id:"nck_r2",cat:"necklace",rarity:"rare",name:"四叶草颈链"},{id:"nck_r3",cat:"necklace",rarity:"rare",name:"月光石坠"},{id:"nck_r4",cat:"necklace",rarity:"rare",name:"蝴蝶银坠"},{id:"nck_r5",cat:"necklace",rarity:"rare",name:"蔷薇花坠"},{id:"nck_r6",cat:"necklace",rarity:"rare",name:"白贝母吊坠"},{id:"nck_r7",cat:"necklace",rarity:"rare",name:"珍珠蝴蝶链"},{id:"nck_r8",cat:"necklace",rarity:"rare",name:"星芒宝石坠"},{id:"nck_e1",cat:"necklace",rarity:"epic",name:"银河碎钻"},{id:"nck_e2",cat:"necklace",rarity:"epic",name:"天鹅湖坠链"},{id:"nck_e3",cat:"necklace",rarity:"epic",name:"月桂星辉"},{id:"nck_e4",cat:"necklace",rarity:"epic",name:"蔷薇星河"},{id:"nck_l1",cat:"necklace",rarity:"legendary",name:"心火红宝坠"},{id:"nck_l2",cat:"necklace",rarity:"legendary",name:"月神辉光"},{id:"nck_x1",cat:"necklace",rarity:"limited",name:"深渊人鱼泪"},{id:"brc_c1",cat:"bracelet",rarity:"common",name:"红绳编织链"},{id:"brc_c2",cat:"bracelet",rarity:"common",name:"小银珠手链"},{id:"brc_c3",cat:"bracelet",rarity:"common",name:"细银环手链"},{id:"brc_c4",cat:"bracelet",rarity:"common",name:"双层细链"},{id:"brc_c5",cat:"bracelet",rarity:"common",name:"小星银链"},{id:"brc_c6",cat:"bracelet",rarity:"common",name:"月牙细链"},{id:"brc_c7",cat:"bracelet",rarity:"common",name:"珍珠串珠链"},{id:"brc_c8",cat:"bracelet",rarity:"common",name:"蝴蝶结细链"},{id:"brc_c9",cat:"bracelet",rarity:"common",name:"银叶编织链"},{id:"brc_c10",cat:"bracelet",rarity:"common",name:"小铃铛银链"},{id:"brc_c11",cat:"bracelet",rarity:"common",name:"心形银链"},{id:"brc_r1",cat:"bracelet",rarity:"rare",name:"粉晶招福链"},{id:"brc_r2",cat:"bracelet",rarity:"rare",name:"铃兰垂坠链"},{id:"brc_r3",cat:"bracelet",rarity:"rare",name:"月光石串链"},{id:"brc_r4",cat:"bracelet",rarity:"rare",name:"蝴蝶流珠链"},{id:"brc_r5",cat:"bracelet",rarity:"rare",name:"蔷薇缠枝链"},{id:"brc_r6",cat:"bracelet",rarity:"rare",name:"贝母花瓣链"},{id:"brc_r7",cat:"bracelet",rarity:"rare",name:"蓝晶水滴链"},{id:"brc_r8",cat:"bracelet",rarity:"rare",name:"四叶幸运链"},{id:"brc_e1",cat:"bracelet",rarity:"epic",name:"极光蛋白链"},{id:"brc_e2",cat:"bracelet",rarity:"epic",name:"时之沙漏链"},{id:"brc_e3",cat:"bracelet",rarity:"epic",name:"星河流光链"},{id:"brc_e4",cat:"bracelet",rarity:"epic",name:"月桂秘银链"},{id:"brc_l1",cat:"bracelet",rarity:"legendary",name:"龙鳞鎏金链"},{id:"brc_l2",cat:"bracelet",rarity:"legendary",name:"圣白金铃链"},{id:"brc_x1",cat:"bracelet",rarity:"limited",name:"永夜玫瑰链"},{id:"ear_c1",cat:"earring",rarity:"common",name:"米粒珍珠钉"},{id:"ear_c2",cat:"earring",rarity:"common",name:"几何银片坠"},{id:"ear_c3",cat:"earring",rarity:"common",name:"细银圆环"},{id:"ear_c4",cat:"earring",rarity:"common",name:"小星银钉"},{id:"ear_c5",cat:"earring",rarity:"common",name:"月牙银坠"},{id:"ear_c6",cat:"earring",rarity:"common",name:"小花银钉"},{id:"ear_c7",cat:"earring",rarity:"common",name:"水滴银坠"},{id:"ear_c8",cat:"earring",rarity:"common",name:"迷你蝴蝶钉"},{id:"ear_c9",cat:"earring",rarity:"common",name:"银珠耳圈"},{id:"ear_c10",cat:"earring",rarity:"common",name:"双珠细坠"},{id:"ear_c11",cat:"earring",rarity:"common",name:"小叶银坠"},{id:"ear_r1",cat:"earring",rarity:"rare",name:"星尘流苏坠"},{id:"ear_r2",cat:"earring",rarity:"rare",name:"蝴蝶蓝宝坠"},{id:"ear_r3",cat:"earring",rarity:"rare",name:"月光石耳坠"},{id:"ear_r4",cat:"earring",rarity:"rare",name:"珍珠花瓣坠"},{id:"ear_r5",cat:"earring",rarity:"rare",name:"蔷薇银枝坠"},{id:"ear_r6",cat:"earring",rarity:"rare",name:"四叶宝石坠"},{id:"ear_r7",cat:"earring",rarity:"rare",name:"蓝晶水滴坠"},{id:"ear_r8",cat:"earring",rarity:"rare",name:"白贝母耳坠"},{id:"ear_e1",cat:"earring",rarity:"epic",name:"极昼冰晶坠"},{id:"ear_e2",cat:"earring",rarity:"epic",name:"黑天鹅羽坠"},{id:"ear_e3",cat:"earring",rarity:"epic",name:"银河蝶影坠"},{id:"ear_e4",cat:"earring",rarity:"epic",name:"月桂星辉坠"},{id:"ear_l1",cat:"earring",rarity:"legendary",name:"凤鸣金环"},{id:"ear_l2",cat:"earring",rarity:"legendary",name:"帝冠翡翠坠"},{id:"ear_x1",cat:"earring",rarity:"limited",name:"晨曦之泪"}],nt=t=>H.find(e=>e.id===t),ne={SSS:{key:"SSS",name:"神秘盲盒",price:50,desc:"1 普通 + 3 稀有 + 1 史诗 + 2 随机",slots:[{rarity:"common",n:1},{rarity:"rare",n:3},{rarity:"epic",n:1},{rarity:"wild",n:3,odds:[["epic",.8],["legendary",.15],["limited"]]}]}},ge=10,S={red:{key:"red",name:"红",hex:"#FF5A5A",type:"moneyMult",val:.1,pair:"本单收入 +10%"},gold:{key:"gold",name:"金",hex:"#FFD98E",type:"fans",val:5,pair:"粉丝 +5"},blue:{key:"blue",name:"蓝",hex:"#5AA9FF",type:"heat",val:1,pair:"热度 +1"},purple:{key:"purple",name:"紫",hex:"#C77DFF",type:"fans",val:2,pair:"粉丝 +2"},green:{key:"green",name:"绿",hex:"#7DE2D1",type:"moneyMult",val:.05,pair:"本单收入 +5%"},secret_s:{key:"secret_s",name:"秘",hex:"#EBBC7F",type:"addBag",val:1,pair:"小隐藏 · 加拆1袋",isSecret:"small"},secret_b:{key:"secret_b",name:"幻",hex:"#FF5EC8",type:"pickStyle",val:1,pair:"大隐藏 · 自选款式",isSecret:"big"}},V=Object.keys(S);function We(t){var s,c;const e=S[t];if(!e)return{type:"none",val:0};if(e.type==="addBag"||e.key==="secret_s")return{type:"addBag",val:1};if(e.type==="pickStyle"||e.key==="secret_b")return{type:"pickStyle",val:1};const n=e.pair||"",a=n.match(/([0-9]+(?:\.[0-9]+)?)\s*%/);if(a)return{type:"moneyMult",val:parseFloat(a[1])/100};if(n.includes("热度")||e.type==="heat"){const i=n.match(/([0-9]+)/);return{type:"heat",val:i?parseInt(i[1],10):(s=e.val)!=null?s:1}}if(n.includes("粉丝")||e.type==="fans"){const i=n.match(/([0-9]+)/);return{type:"fans",val:i?parseInt(i[1],10):(c=e.val)!=null?c:2}}return{type:e.type||"none",val:e.val||0}}const ae=[{key:"rookie",name:"新人主播",fans:100,orders:[1,3],bags:[4,6],cap:50,fanMult:1},{key:"small",name:"小主播",fans:1e3,orders:[3,5],bags:[4,7],cap:100,fanMult:2},{key:"waist",name:"腰部主播",fans:1e4,orders:[5,8],bags:[5,9],cap:150,fanMult:4},{key:"big",name:"大主播",fans:1e5,orders:[8,10],bags:[6,12],cap:200,fanMult:7}];function Kt(t){let e=ae[0];for(const n of ae)t>=n.fans&&(e=n);return e}function Ve(t){return ae.find(e=>e.fans>t)||null}const _e=[{key:"ruby",name:"红宝石",hex:"#FF5A5A"},{key:"sapphire",name:"蓝宝石",hex:"#5AA9FF"},{key:"emerald",name:"翡翠",hex:"#7DE2D1"},{key:"diamond",name:"钻石",hex:"#F5EFE6"},{key:"catseye",name:"猫眼石",hex:"#FFD98E"}],Je=200,Ke=800,Qe=3,Zt=50,Ze=1e4,Ot=200,tn=.15,Le=15,Ie=3,Ae=1.5,jt=3,Ut=8,en=.15,nn=.01,an=[{min:11,name:"全场爆满",mult:1.3,stars:5,comments:["今天这间直播间我愿称之为神！","已下单三单，钱包已阵亡","主播手气也太好了吧，关注了！"]},{min:6,name:"观众满意",mult:1.1,stars:4,comments:["拆袋过程很上头，明天还来","对对碰那下我直接站起来了","饰品成色不错，值回票价"]},{min:2,name:"反应平平",mult:1,stars:3,comments:["还行吧，希望明天上点新款式","运气一般，隔壁直播间更欧","袋子有点少，没抢到想要的"]},{min:-99,name:"有点翻车",mult:.6,stars:2,comments:["缺货算怎么回事？取关了","就这？我等了半小时","今天风向都没看就开播？"]}],sn={ring:"今天戒指卖爆了，姐妹们都在求戒指盲袋！",necklace:"项链是今天的顶流，锁骨链话题度拉满！",bracelet:"手链热度飙升，编绳款被抢疯了！",earring:"今天耳环是流量密码，耳饰控集体出动！"},at={enter:["来了来了！","主播晚上好~","今天拆什么？","前排围观！","钱包已就位"],order:["新订单来了！","这单我要看！","冲冲冲！","接单接单！"],lucky:["幸运色！多拆一袋！","欧气满满！","这波血赚！"],pair:["对对碰！！","碰一碰！","主播手气无敌！","又碰上了！"],epic:["史诗！！","出金了！","这袋子有毒吧！","羡慕住了"],legendary:["传说！！！","全网第一欧！","我也要抽这个！","主播嫁我！"],stockout:["缺货了？就这？","备货不足啊主播","下播去补货吧"],secret_s:["出小隐藏了！多加一袋！","小隐藏！！欧气爆表！","加拆加拆！老板大气！","吸吸小隐藏欧气！"],secret_b:["全场起立！！大隐藏降临！","出大隐藏了！","单主快选款！！羡慕哭了","天选单主！大隐藏绝杀！"],limited:["限定！限定！","这个必须冲！","绝版好嘛，买！"],generic:["好看好看","已拍已拍","求上项链！","硬币是什么颜色？","主播加油！","蹲一个传说"]},Wt=new Set;let mt=null;function Pe(){return{day:1,money:1e3,fans:100,trend:{cat:"ring",lucky:"red",style:"ring_c1",saleStyle:"ring_c1",saleDiscount:.5},streamsLeft:jt,stock:{},codex:[],codexBonus:[],packed:{},heldOrders:[],vault:[],gems:[],shop:[],adBoostUsedToday:!1,stats:null,screen:"intro",dayTab:"shop",muted:!1}}function cn(t){return mt=t,Wt.forEach(e=>e(mt)),mt}function w(){return mt}function bt(t){return mt=typeof t=="function"?t(mt):et(et({},mt),t),Wt.forEach(e=>e(mt)),mt}function rn(t){return Wt.add(t),()=>Wt.delete(t)}function re(t=mt){const s=t,{screen:e,dayTab:n}=s,a=ve(s,["screen","dayTab"]);return JSON.parse(JSON.stringify(a))}function Fe(){return{earn:0,earnBase:0,earnBuff:0,ordersDone:0,bagsSold:0,pairs:0,luckyHits:0,trendHits:0,stockouts:0,epicsPulled:0,limitedSold:0,evalBonus:0,fansToday:0,settledFans:0,heatBonus:0,bestPull:null}}const At="save:slot1",zt="save:blindbag",on=1;let Ct=null,oe=0;function ln(t){Ct=t}function le(){var t;return Ct!=null&&Ct.storage&&typeof Ct.storage.get=="function"?Ct.storage:typeof window!="undefined"&&((t=window.sdk)!=null&&t.storage)&&typeof window.sdk.storage.get=="function"?window.sdk.storage:null}function ke(t){if(!t)return null;let e=t;if(typeof t=="string")try{e=JSON.parse(t)}catch(n){return null}return e&&typeof e=="object"&&"value"in e&&e.value&&typeof e.value=="object"&&(e=e.value),e&&typeof e=="object"&&typeof e.day=="number"?e:null}function dn(){return Et(this,null,function*(){const t=le();let e=null;if(t)try{let a=yield t.get({key:At,scope:"user"});a!=null&&a.value||(a=yield t.get({key:zt,scope:"user"})),a&&a.value&&(oe=a.version||0,e=ke(a.value))}catch(a){console.warn("[save] platform storage.get failed, falling back",a)}let n=null;try{const a=localStorage.getItem(At)||localStorage.getItem(zt);n=ke(a)}catch(a){console.warn("[save] localStorage.getItem failed",a)}if(e&&n){const a=e.updatedAt||0,s=n.updatedAt||0;return e.day>n.day?e:n.day>e.day?n:a>=s?e:n}return e||n||null})}function st(t){return Et(this,null,function*(){const e=t!=null?t:re(w());if(!e||typeof e!="object")return;const n=pt(et({v:on},e),{updatedAt:Date.now()});try{const s=JSON.stringify(n);localStorage.setItem(At,s),localStorage.setItem(zt,s)}catch(s){console.warn("[save] local save failed",s)}const a=le();if(a)try{const s=yield a.set({key:At,value:n,scope:"user"});s!=null&&s.version&&(oe=s.version)}catch(s){console.warn("[save] platform storage.set failed",s)}})}function pn(){return Et(this,null,function*(){oe=0;try{localStorage.removeItem(At),localStorage.removeItem(zt)}catch(e){}const t=le();if(t)try{yield t.del({key:At,scope:"user"}),yield t.del({key:zt,scope:"user"})}catch(e){console.warn("[save] platform storage.del failed",e)}})}const gt=t=>Math.floor(Math.random()*t),ft=(t,e)=>t+gt(e-t+1),tt=t=>t[gt(t.length)];function un(t,e){return H.filter(n=>n.cat===t&&n.rarity===e)}function mn(t){let e=Math.random();for(const[n,a]of t)if(e-=a,e<0)return n;return t[t.length-1][0]}function Ne(t,e,n="SSS"){const a=ne[n]||ne.SSS,s=(a==null?void 0:a.price)||50;if(t.money<s)return{ok:!1,reason:"money"};t.money-=s;const c=[];for(const i of a.slots)for(let r=0;r<i.n;r++){const d=i.rarity==="wild"?mn(i.odds):i.rarity,l=un(e,d),o=tt(l),u=!t.codex.includes(o.id);u?(t.codex.push(o.id),t.stock[o.id]=(t.stock[o.id]||0)+ge):t.stock[o.id]=(t.stock[o.id]||0)+J[d].restock,c.push({design:o,isNew:u,grant:u?ge:J[d].restock})}return yn(t,e),{ok:!0,cost:a.price,items:c}}function yn(t,e){if(t.codexBonus.includes(e))return;H.filter(a=>a.cat===e&&a.rarity!=="limited").every(a=>t.codex.includes(a.id))&&(t.codexBonus.push(e),t.money+=300,t.fans+=100)}function fn(t,e,n=1){const a=nt(e);let s=J[a.rarity].unitPrice;if(t.trend&&t.trend.saleStyle===e){const i=t.trend.saleDiscount||.5;s=Math.max(1,Math.round(s*i))}const c=s*n;return t.money<c?{ok:!1,reason:"money"}:(t.money-=c,t.stock[e]=(t.stock[e]||0)+n,{ok:!0,cost:c,unitPrice:s})}function Dt(t){switch(t){case"legendary":return ft(96,99);case"epic":return ft(88,95);case"rare":return ft(75,87);case"limited":return ft(95,99);case"common":default:return ft(50,74)}}function $e(t,e,n,a){const s=n.length;if(s===0)return{ok:!1,reason:"empty"};const c={};for(const o of n)c[o]=(c[o]||0)+1;for(const[o,u]of Object.entries(c))if((t.stock[o]||0)<u)return{ok:!1,reason:"stock",designId:o};let i=0;for(const o of V)i+=a[o]||0;if(i!==s)return{ok:!1,reason:"coinSum"};for(const[o,u]of Object.entries(c))t.stock[o]-=u;const r=[];for(const o of V)for(let u=0;u<(a[o]||0);u++)r.push(o);for(let o=r.length-1;o>0;o--){const u=gt(o+1);[r[o],r[u]]=[r[u],r[o]]}const d=[...n];for(let o=d.length-1;o>0;o--){const u=gt(o+1);[d[o],d[u]]=[d[u],d[o]]}const l=d.map((o,u)=>{const b=nt(o);return{a:o,c:r[u],r:Dt(b==null?void 0:b.rarity)}});for(let o=l.length-1;o>0;o--){const u=gt(o+1);[l[o],l[u]]=[l[u],l[o]]}t.packed[e]=[...t.packed[e]||[],...l];for(let o=t.packed[e].length-1;o>0;o--){const u=gt(o+1);[t.packed[e][o],t.packed[e][u]]=[t.packed[e][u],t.packed[e][o]]}return{ok:!0}}function bn(t,e){for(const n of t.packed[e]||[])t.stock[n.a]=(t.stock[n.a]||0)+1;t.packed[e]=[]}function hn(t,e,n){const a=[];for(const c of H){if(c.cat!==e)continue;const i=t.stock[c.id]||0;for(let r=0;r<i;r++)a.push(c.id)}const s=["legendary","epic","rare","common"];return a.sort((c,i)=>{const r=J[nt(c).rarity],d=J[nt(i).rarity];return s.indexOf(r.key)-s.indexOf(d.key)}),a.slice(0,n)}const se=["芝芝桃桃","欧气满满","小猫打呼噜","星河碎碎冰","今天不熬夜","奶糖泡泡","草莓大福","追光的小鹿","橘子汽水","可可脆脆","软绵绵的云","暴富小锦鲤","啵啵奶茶","咸蛋黄泡芙","momo","甜甜圈圈","柠檬气泡","月亮邮局","薄荷小调","落日飞车","鱼宝","栗子","雨水","小羽毛"];function vn(t){const e=Kt(t.fans),n=[];t.vault.length>0&&n.push({type:"limited",item:t.vault[0],buyerName:"VIP限定买家"}),Array.isArray(t.heldOrders)&&t.heldOrders.length>0&&(n.push(...t.heldOrders.map(r=>pt(et({},r),{buyerName:r.buyerName||tt(se)}))),t.heldOrders=[]);const a=lt.filter(r=>(t.packed[r]||[]).length>0);if(a.length===0)return n;let s=e.cap-n.filter(r=>r.type==="bags").reduce((r,d)=>r+(d.size||0),0);const c=Math.max(0,ft(e.orders[0],e.orders[1])-n.filter(r=>r.type==="bags").length);let i=n.some(r=>r.type==="bags"&&r.cat===t.trend.cat);for(let r=0;r<c&&s>0;r++){let d;!i&&(t.packed[t.trend.cat]||[]).length>0?(d=t.trend.cat,i=!0):d=tt(a);const l=Math.min(ft(e.bags[0],e.bags[1]),s,(t.packed[d]||[]).length+3);if(l<=0)continue;s-=l;const o=tt(se);n.push({type:"bags",cat:d,size:l,lucky:tt(V),buyerName:o})}return n}function gn(t){return{queue:t.type==="bags"?t.size:0,tally:{},moneyMult:0,redMult:0,greenMult:0,styleFans:0,opened:[],buffs:[],pairs:0,luckyHits:0,stockouts:0,goldFans:0,evalScore:0,heatAdd:0,done:!1}}function kn(t,e,n){var b,B,M,m,v,g;if(n.done)return null;n.queue>0&&n.queue--;const a=n.opened.length>=e.size,s=t.packed[e.cat]||[];let c=null;if(e.trayBags&&e.trayBags.length>0){let f=0;if(e.trayBags.length>1&&n.opened.length>0){const $=(B=(b=n.opened[n.opened.length-1])==null?void 0:b.design)==null?void 0:B.id;if($&&((M=e.trayBags[0])==null?void 0:M.a)===$){const P=e.trayBags.findIndex(C=>C.a!==$);P!==-1&&(f=P)}}c=e.trayBags.splice(f,1)[0]}else if(s.length>0){let f=gt(s.length);if(s.length>1&&n.opened.length>0){const $=(v=(m=n.opened[n.opened.length-1])==null?void 0:m.design)==null?void 0:v.id;if($&&((g=s[f])==null?void 0:g.a)===$&&s.findIndex(C=>C.a!==$)!==-1){const C=[];for(let R=0;R<s.length;R++)s[R].a!==$&&C.push(R);f=C[gt(C.length)]}}c=s.splice(f,1)[0]}let i=null,r=null,d=ft(50,100);if(c)i=nt(c.a),r=c.c,d=Dt(i==null?void 0:i.rarity);else if(a){const f=H.filter($=>$.cat===e.cat&&$.rarity!=="limited");i=f.length>0?tt(f):H[0],r=tt(V),d=Dt(i==null?void 0:i.rarity)}else return n.stockouts++,n.opened.push({slot:"stockout"}),{slot:"stockout"};let l=!1;if(i&&i.rarity==="common"&&Math.random()<.05){const f=H.filter($=>$.cat===e.cat&&($.rarity==="rare"||$.rarity==="epic"));f.length>0&&(i=tt(f),d=Dt(i==null?void 0:i.rarity),l=!0)}const o=d>=88;o&&(n.critBonus=(n.critBonus||0)+10),n.opened.push({slot:a?"bonus":"order",design:i,coin:r,luckyVal:d,isCrit:o,upgraded:l});const u={slot:a?"bonus":"order",design:i,coin:r,bonus:a,luckyHit:!1,luckyVal:d,isCrit:o,upgraded:l};return i&&(i.rarity==="epic"||i.rarity==="legendary")&&((!t.stats.bestPull||J[i.rarity].bonus>J[t.stats.bestPull.rarity].bonus)&&(t.stats.bestPull={rarity:i.rarity,name:i.name}),t.stats.epicsPulled++),i&&t.trend.style&&i.id===t.trend.style&&(n.styleFans=(n.styleFans||0)+1,u.styleHit=!0),r===e.lucky&&(n.luckyHits++,n.queue++,u.luckyHit=!0),r==="secret_s"&&(n.queue++,u.isSecretSmall=!0),r==="secret_b"&&(u.isSecretBig=!0),r&&(n.tally[r]=(n.tally[r]||0)+1),u}function $n(t,e,n,a){var i;const s=(i=t==null?void 0:t.trend)==null?void 0:i.lucky;n.tally[a]=(n.tally[a]||0)-2,n.pairs++,n.queue++;let c=!1;if(s&&a===s){c=!0;const r=We(a);r.type==="moneyMult"?n.moneyMult=(n.moneyMult||0)+r.val:r.type==="fans"?n.goldFans=(n.goldFans||0)+r.val:r.type==="heat"&&(n.heatAdd=(n.heatAdd||0)+r.val);const d=a.startsWith("secret")?S[a].name:`${S[a].name}色`;n.buffs.push({key:a,name:`${d}对碰`,desc:S[a].pair})}return{colorKey:a,isLucky:c}}function Oe(t,e,n){if(n.done=!0,e.type==="limited"){const b=e.item.price;return t.money+=b,t.fans+=Zt,t.vault.shift(),t.stats.earn+=b,t.stats.earnBase=(t.stats.earnBase||0)+b,t.stats.limitedSold++,t.stats.ordersDone++,t.stats.fansToday+=Zt,t.stats.bestPull=t.stats.bestPull||{rarity:"limited",name:nt(e.item.designId).name},{price:b,fans:Zt}}const a=e.size,s=e.cat===t.trend.cat;s&&t.stats.trendHits++;const c=(Le+a*Ie)*(s?Ae:1),i=Math.round(c),r=(n.moneyMult||0)+(n.redMult||0)+(n.greenMult||0),d=n.critBonus||0;let l=Math.round(c*(1+r))+d;e.doublePrice&&(l=l*2);const o=i*(e.doublePrice?2:1),u=Math.round((5+n.opened.filter(b=>b.design).length*2+n.pairs*5)*Kt(t.fans).fanMult)+(n.goldFans||0)+(n.styleFans||0);return t.money+=l,t.fans+=u,t.stats.earn+=l,t.stats.earnBase=(t.stats.earnBase||0)+o,t.stats.earnBuff=(t.stats.earnBuff||0)+(l-o),t.stats.ordersDone++,t.stats.bagsSold+=a,t.stats.evalBonus=(t.stats.evalBonus||0)+n.evalScore,t.stats.pairs+=n.pairs,t.stats.luckyHits+=n.luckyHits,t.stats.stockouts+=n.stockouts,t.stats.fansToday+=u,{price:l,fans:u,trendHit:s,base:o,buffPart:l-o,critBonus:d,doublePrice:!!e.doublePrice}}function de(t){t.gems=[];for(let e=0;e<Qe;e++){const n=tt(_e);t.gems.push({gem:n.key,price:ft(Je,Ke)})}}function xn(t){return an.find(e=>t>=e.min)}function Sn(t,{isLastStream:e=!1}={}){var r;const n=t.stats.trendHits*2+t.stats.pairs+t.stats.epicsPulled+t.stats.evalBonus+t.stats.limitedSold*2-t.stats.stockouts*2,a=xn(n),s=t.stats.fansToday-(t.stats.settledFans||0),c=Math.round(s*(a.mult-1));t.fans+=c,t.stats.settledFans=t.stats.fansToday;let i=!1;return e&&t.money<((r=ne.SSS)==null?void 0:r.price)&&wn(t)===0&&(t.money+=150,i=!0),{score:n,level:a,fanBonus:c,mercy:i}}function wn(t){let e=0;for(const n of lt)e+=(t.packed[n]||[]).length;for(const n of Object.values(t.stock))e+=n;return e}function De(t){t.day++;const e=tt(lt),n=Ht(t,e),a=pe(t,e,n);t.trend={cat:e,lucky:tt(V),style:n,saleStyle:a,saleDiscount:.5},t.streamsLeft=jt,t.adBoostUsedToday=!1,t.stats=null,t.shop=Pt(),de(t)}function pe(t,e,n){const a=H.filter(c=>c.cat===e&&c.rarity!=="limited"&&((t==null?void 0:t.codex)||[]).includes(c.id));if(a.length>0&&Math.random()<.75)return tt(a).id;const s=H.filter(c=>c.cat===e&&c.rarity!=="limited");return s.length===0?n:tt(s).id}function Ht(t,e){const n=H.filter(a=>a.cat===e&&a.rarity!=="limited");return n.length>0?tt(n).id:null}function Pt(t){const e=[];for(let n=0;n<10;n++)e.push({cat:tt(lt),tier:"SSS",price:50,sold:!1});return e.map((n,a)=>pt(et({},n),{slot:a+1}))}let Tt=null,ue=!1;function ze(t){ue=t}function He(){if(!Tt){const t=window.AudioContext||window.webkitAudioContext;t&&(Tt=new t)}return Tt&&Tt.state==="suspended"&&Tt.resume(),Tt}function z(t,e,{type:n="sine",vol:a=.15,delay:s=0,slide:c=0}={}){const i=He();if(!i||ue)return;const r=i.currentTime+s,d=i.createOscillator(),l=i.createGain();d.type=n,d.frequency.setValueAtTime(t,r),c&&d.frequency.exponentialRampToValueAtTime(Math.max(40,t+c),r+e),l.gain.setValueAtTime(0,r),l.gain.linearRampToValueAtTime(a,r+.01),l.gain.exponentialRampToValueAtTime(.001,r+e),d.connect(l).connect(i.destination),d.start(r),d.stop(r+e+.05)}function Gt(t,{vol:e=.12,delay:n=0,hp:a=800}={}){const s=He();if(!s||ue)return;const c=s.currentTime+n,i=Math.floor(s.sampleRate*t),r=s.createBuffer(1,i,s.sampleRate),d=r.getChannelData(0);for(let b=0;b<i;b++)d[b]=(Math.random()*2-1)*(1-b/i);const l=s.createBufferSource();l.buffer=r;const o=s.createBiquadFilter();o.type="highpass",o.frequency.value=a;const u=s.createGain();u.gain.setValueAtTime(e,c),u.gain.exponentialRampToValueAtTime(.001,c+t),l.connect(o).connect(u).connect(s.destination),l.start(c)}const Mn={tap:()=>z(660,.06,{type:"triangle",vol:.08}),click:()=>z(660,.06,{type:"triangle",vol:.08}),buy:()=>{z(520,.08,{type:"triangle",vol:.1}),z(780,.1,{type:"triangle",vol:.1,delay:.07})},tear:()=>Gt(.18,{vol:.14,hp:1200}),coin:()=>{z(880,.09,{vol:.12}),z(1320,.14,{vol:.1,delay:.06})},pair:()=>{z(220,.2,{type:"square",vol:.12,slide:220}),Gt(.12,{vol:.1,hp:400}),z(1046,.16,{vol:.12,delay:.1})},cash:()=>{z(784,.09,{vol:.12}),z(988,.09,{vol:.12,delay:.08}),z(1318,.18,{vol:.12,delay:.16})},rare:()=>{z(660,.1,{vol:.12}),z(880,.1,{vol:.12,delay:.09}),z(1174,.22,{vol:.12,delay:.18})},legendary:()=>{[523,659,784,1046,1318].forEach((t,e)=>z(t,.22,{vol:.13,delay:e*.09}))},fans:()=>{z(587,.08,{vol:.09}),z(880,.12,{vol:.09,delay:.06})},bad:()=>z(180,.25,{type:"sawtooth",vol:.08,slide:-60}),warn:()=>z(220,.2,{type:"sawtooth",vol:.09,slide:-40}),zip:()=>Gt(.05,{vol:.09,hp:1800}),seal:()=>{Gt(.1,{vol:.1,hp:1500}),z(880,.08,{type:"triangle",vol:.12}),z(1320,.14,{type:"triangle",vol:.12,delay:.06})}},y=new Proxy(Mn,{get(t,e){return e in t?t[e]:t.tap}});function $t(t,e,n="#FFD98E",a=!1){if(!t)return;const s=t.getBoundingClientRect(),c=document.createElement("span");c.className="fx-float"+(a?" fx-float-big":""),c.textContent=e,c.style.color=n,c.style.left=`${s.left+s.width/2}px`,c.style.top=`${s.top+s.height/3}px`,document.body.appendChild(c),c.addEventListener("animationend",()=>c.remove())}function kt(t,e,n=["#FFD98E","#FF7EB6"],a=14){for(let s=0;s<a;s++){const c=document.createElement("span");c.className="fx-particle",c.style.left=`${t}px`,c.style.top=`${e}px`,c.style.background=n[s%n.length];const i=Math.random()*Math.PI*2,r=40+Math.random()*70;c.animate([{transform:"translate(-50%,-50%) scale(1)",opacity:1},{transform:`translate(calc(-50% + ${Math.cos(i)*r}px), calc(-50% + ${Math.sin(i)*r}px)) scale(0.2)`,opacity:0}],{duration:500+Math.random()*400,easing:"cubic-bezier(.1,.6,.3,1)"}).onfinish=()=>c.remove(),document.body.appendChild(c)}}function Lt(t,e=0){t&&t.animate([{transform:"scale(0.4)",opacity:0},{transform:"scale(1.08)",opacity:1,offset:.7},{transform:"scale(1)",opacity:1}],{duration:380,delay:e,easing:"cubic-bezier(.2,1.4,.4,1)",fill:"backwards"})}const qe=t=>Math.floor(Math.random()*t),Bn=(t,e)=>t+qe(e-t+1),It=t=>t[qe(t.length)];let p=null,ht=[];function En(){ht.forEach(t=>clearInterval(t)),ht=[]}function Tn(){const t=w();if(t.streamsLeft<=0)return L("今天的直播场次用完啦，先休息吧","warn");t.stats||(t.stats=Fe());const e=vn(t);if(e.length===0)return L("先去装袋，再开播","warn");const n=Math.random()<.1,a=Math.random()<.5;p={orders:e,idx:-1,ctx:null,order:null,heat:Math.ceil(t.fans*en),streamStarted:!1,hasRandomEvent:n,randomEventTriggered:!1,randomEventIsGain:a,totalBagsOpened:0,adBoostPrompted:!1},bt({screen:"live"}),st()}function Cn(t){const e=w();t.innerHTML=`
    <div class="live-wrap">
      <div class="live-head">
        <span class="live-dot"></span><b>直播中</b>
        <span class="live-heat" id="heatWrap" title="每拆一袋 +1 热度；下播时热度超过粉丝数，全场涨粉 5%">热度：<b id="heatNum">0</b></span>
        <span class="live-trend">风向 ${X[e.trend.cat].name}${e.trend.style?` · ${nt(e.trend.style).name}`:""}</span>
        <span class="live-count">今日剩 ${e.streamsLeft} 场</span>
      </div>
      <div class="stage" id="stage"></div>
      <div class="live-foot">
        <span>营收 <b id="lfEarn">¥${e.stats.earn}</b></span>
        <span>订单 <b id="lfOrders">${e.stats.ordersDone}</b></span>
        <span>对碰 <b id="lfPairs">${e.stats.pairs}</b></span>
        <span>粉丝 <b id="lfFans">+${e.stats.fansToday}</b></span>
        <span>剩余盲袋 <b id="lfBags">${lt.reduce((a,s)=>a+(e.packed[s]||[]).length,0)}</b></span>
        <button class="btn btn-mini btn-end" id="lfEnd">下播</button>
      </div>
    </div>`,t.querySelector("#lfEnd").onclick=()=>Ln(),Qt();const n=t.querySelector("#stage");n.innerHTML='<div class="live-intro"><div class="li-ic">📡</div><b>直播准备中…</b><span>观众正在涌入</span></div>',e.fans>=Ze&&!e.adBoostUsedToday&&!p.adBoostPrompted?(p.adBoostPrompted=!0,In(n,()=>{ht.push(setTimeout(()=>qt(n),800))})):ht.push(setTimeout(()=>qt(n),1400))}const xe=["芝芝桃桃","欧气满满","小猫打呼噜","星河碎碎冰","今天不熬夜","奶糖泡泡","草莓大福","追光的小鹿","橘子汽水","可可脆脆","软绵绵的云","暴富小锦鲤","啵啵奶茶","咸蛋黄泡芙","momo","甜甜圈圈","柠檬气泡","月亮邮局","薄荷小调","落日飞车","芋泥波波","雪顶咖啡","晴天小狗","乌龙烤奶","多肉葡萄","浅草微风","丸子酱","青提气泡水","早睡早起","锦鲤附体","棉花糖","布丁豆豆","焦糖布蕾","快乐小羊","奶茶续命选手","良良","小熊软糖","冰摇红莓","海盐芝士","旺仔牛奶","山楂气泡","风铃草","白桃乌龙","云朵舒芙蕾","星星糖","抹茶拿铁","栗子蛋糕","小确幸","偷得浮生","晚风温柔","拿铁","可爱徐宝"];function _n(){var a;const t=new Set(((p==null?void 0:p.orders)||[]).map(s=>s.buyerName).filter(Boolean));(a=p==null?void 0:p.order)!=null&&a.buyerName&&t.add(p.order.buyerName);const e=xe.filter(s=>!t.has(s)),n=e.length>0?e:xe;return n[Math.floor(Math.random()*n.length)]}function wt(t,e=0){const n=p==null?void 0:p.order;if(!n)return;const a=n.buyerName||"单主";ht.push(setTimeout(()=>{const s=document.getElementById("danmaku");if(!s)return;const c=document.createElement("div");for(c.className="chat-item chat-item-buyer",c.innerHTML=`<span class="ci-buyer-badge">单主</span><span class="ci-user ci-buyer-name">${a}</span><span class="ci-sep">:</span><span class="ci-text ci-buyer-text">${t}</span>`,s.appendChild(c);s.children.length>8;)s.removeChild(s.firstChild)},e))}function Qt(){const t=w(),e=document.getElementById("heatNum"),n=document.getElementById("heatWrap");!e||!n||(e.textContent=`${p.heat}`,n.classList.toggle("hot",p.heat>t.fans))}function Ln(){var a,s,c;const t=w(),e=document.getElementById("stage");if(((s=(a=p==null?void 0:p.order)==null?void 0:a.trayBags)==null?void 0:s.length)>0&&p.order.cat&&(t.packed[p.order.cat]=[...t.packed[p.order.cat]||[],...p.order.trayBags],p.order.trayBags=[]),!p||!p.ctx||p.ctx.done||((c=p.order)==null?void 0:c.type)==="limited"||!e)return _t(e);const n=Oe(t,p.order,p.ctx);xt(t),$t(document.querySelector(".live-foot"),`+¥${n.price}`,"#FFD98E"),L(`这单提前收尾 +¥${n.price}`),_t(e)}function O(t,e=1,n=0){if(!document.getElementById("danmaku"))return;const s=Array.isArray(t)?t:[t];if(s.length===0)return;const c=[],i=[...s].sort(()=>Math.random()-.5);for(let r=0;r<e;r++)c.push(i[r%i.length]);for(let r=0;r<c.length;r++)ht.push(setTimeout(()=>{const d=document.getElementById("danmaku");if(!d)return;const l=c[r],o=_n(),u=document.createElement("div");for(u.className="chat-item",u.innerHTML=`<span class="ci-user">${o}</span><span class="ci-sep">:</span><span class="ci-text">${l}</span>`,d.appendChild(u);d.children.length>8;)d.removeChild(d.firstChild)},n+r*280))}function W(t,e,n,a=""){const s=document.getElementById("liveEventFeed");if(!s)return;const c=document.createElement("div");for(c.className=`live-notice ln-${t}`,c.innerHTML=`
    <span class="ln-badge">${e}</span>
    <span class="ln-body">
      <span class="ln-desc">${n}</span>
      ${a?`<span class="ln-extra">${a}</span>`:""}
    </span>`,s.appendChild(c);s.children.length>8;)s.removeChild(s.firstChild)}function In(t,e){const n=w(),a=n.money>=Ot,{close:s}=yt(`
    <div class="ad-boost-modal">
      <div class="abm-head">
        <span class="abm-badge">🔥 腰部主播特权 · 每日投流</span>
        <h3 class="m-title" style="margin-bottom:2px;">开启平台推流</h3>
      </div>
      <p class="abm-desc">
        粉丝数已达 <b>10,000</b>！可花费金币向平台购买专属推流服务，迅速引爆直播间热度并引流优质买家。
      </p>
      <div class="abm-card">
        <div class="abm-item">
          <span class="abm-ic">🚀</span>
          <div class="abm-text">
            <b>热度暴涨 · 突破粉丝数 20%</b>
            <span>投流后当场直播热度大幅提升，直接达标平台爆款推流池。</span>
          </div>
        </div>
        <div class="abm-item">
          <span class="abm-ic">💎</span>
          <div class="abm-text">
            <b>额外追加 1 笔【双倍价格】订单</b>
            <span>热度超过 20% 平台追加优质大单，该订单享受<b>双倍价格收益</b>！</span>
          </div>
        </div>
        <div class="abm-price-bar">
          <span>投流服务费：<b>¥${Ot}</b></span>
          <small>当前余额 ¥${n.money} · 今日限投 1 次</small>
        </div>
      </div>
      <div class="abm-actions">
        <button class="btn btn-ghost" id="abmSkip">暂不投流，直接开播</button>
        <button class="btn btn-primary" id="abmConfirm" ${a?"":"disabled"}>
          ${a?`花费 ¥${Ot} 确认投流`:"余额不足 ¥200"}
        </button>
      </div>
    </div>`,{closable:!1}),c=()=>{s(),e()},i=document.getElementById("abmSkip");i&&(i.onclick=()=>{y.tap(),c()});const r=document.getElementById("abmConfirm");r&&(r.onclick=()=>{if(n.money<Ot)return L("金币余额不足","warn");n.money-=Ot,n.adBoostUsedToday=!0;const d=Math.ceil(n.fans*tn);p.heat+=d,Qt();const l=Kt(n.fans),o=lt.filter(M=>(n.packed[M]||[]).length>0),u=(n.packed[n.trend.cat]||[]).length>0?n.trend.cat:o.length>0?It(o):n.trend.cat,b=Math.max(4,Math.min(Bn(l.bags[0],l.bags[1]),(n.packed[u]||[]).length+2)),B={type:"bags",cat:u,size:b,lucky:It(V),buyerName:"🔥推广贵宾·"+It(se),doublePrice:!0,isPromotion:!0};p.orders.push(B),y.cash(),L("🔥 投流成功！热度突破 20%，已引入 1 笔双倍价格推单！"),W("gold","🔥 平台投流",`推流注入！热度 +${d}，增加 1 笔双倍价格推单！`),xt(n),st(),c()})}function Se(t,e){const n=w();if(t){const a=Math.max(15,Math.round(n.fans*(.015+Math.random()*.02)+10)),c=It([{title:"🌟 大V查房",desc:"头部大主播带队前来查房，高呼「这家对对碰太解压了」！路人纷纷点赞关注。",danmaku:["大主播查房！全员集合！","从隔壁直播间过来的！","这手气太神了关注了","主播好有意思啊"]},{title:"🔥 切片上热门",desc:"刚才的高能开盒切片被观众录屏发到短视频平台，点赞破万登上同城热门！",danmaku:["在同城热门刷到的！","特意赶来看直播","刚才那一抽太绝了","关注主播！"]},{title:"🎙️ 金句整活出圈",desc:"主播刚才的幽默接梗被弹幕疯狂打call，直播间互动率飙升，路人纷纷转粉！",danmaku:["哈哈哈哈主播太有梗了","冲着这口才必须关注","每天下饭必看","关注了主播加油"]},{title:"📈 官方算法推流",desc:"直播间高留存表现优异，触发平台流量激励算法，曝光量飙升，新观众大量涌入关注！",danmaku:["系统推荐进来的！","宝藏直播间被我发现了","关注一波","盲盒还能这么玩！"]}]);n.fans+=a,n.stats.fansToday+=a,xt(n),Vt(),y.fans(),W("gold",`🎉 ${c.title}`,`${c.desc}（粉丝 +${a}）`),O(c.danmaku,3,200),e&&$t(e,`+${a} 粉丝`,"#FF7EB6")}else{const a=Math.max(0,n.fans-10),s=Math.min(a,Math.max(5,Math.round(n.fans*(.01+Math.random()*.015)+5))),i=It([{title:"📡 网络波动卡顿",desc:"推流网络突发丢包掉帧，画面短暂卡顿转圈，几位急脾气的观众取关离开了…",danmaku:["刚才是不是卡了一下？","主播卡成PPT了","画质怎么糊了","还好恢复了"]},{title:"🔨 隔壁突发装修",desc:"隔壁突然开启重型电钻施工，刺耳噪音穿透麦克风，劝退了一批喜静的观众…",danmaku:["好吵啊隔壁在干嘛","被电钻声吓一跳","收音太真实了","心疼主播一秒"]},{title:"💬 黑粉公屏带节奏",desc:"公屏混入几个恶意小号刷屏带节奏，部分不明真相的吃瓜路人被误导取关…",danmaku:["房管快出来封人！","别理带节奏的","哪来的小号刷屏","主播专心拆别看弹幕"]},{title:"😅 激动喊劈口误",desc:"主播刚才拆到关键时刻一激动把款式喊劈叉了，几个追求完美的粉丝捂脸取关…",danmaku:["破音了哈哈哈哈","声卡差点当场报销","主播喝口水润润嗓","太搞笑了"]}]);s>0&&(n.fans=Math.max(10,n.fans-s),n.stats.fansToday-=s,xt(n),Vt(),y.bad(),W("loss",`⚠️ ${i.title}`,`${i.desc}（粉丝 -${s}）`),O(i.danmaku,3,200),e&&$t(e,`-${s} 粉丝`,"#8E767C"))}}function Vt(){const t=w(),e=(n,a)=>{const s=document.getElementById(n);s&&(s.textContent=a)};e("lfEarn",`¥${t.stats.earn}`),e("lfOrders",t.stats.ordersDone),e("lfPairs",t.stats.pairs),e("lfFans",`+${t.stats.fansToday}`),e("lfBags",lt.reduce((n,a)=>n+(t.packed[a]||[]).length,0))}function An(t,e){const n=w(),a=t.cat,s=t.size,c=[...n.packed[a]||[]],i=Math.max(c.length,s,8);let r=[];const d=yt(`
    <div class="pick-bags-modal">
      <div class="pbm-head">
        <div class="pbm-title-wrap">
          <h3 class="m-title" style="margin-bottom:2px;">📦 接单备货</h3>
          <span class="pbm-buyer-tag">单主 <b>${t.buyerName||"神秘顾客"}</b></span>
        </div>
      </div>

      <div class="pbm-shelf-sec">
        <div class="pbm-sec-head">
          <span>📦 ${X[a].name}盲袋货架（点盲袋拿取）</span>
          <small>库存已装袋：${c.length} 袋</small>
        </div>
        <div class="pbm-shelf-grid" id="pbmShelf"></div>
      </div>

      <div class="pbm-tray-sec">
        <div class="pbm-sec-head">
          <span>✨ 拆袋台托盘</span>
          <span class="pbm-count-pill">已拿取 <b id="pbmCount">0</b> / ${s} 袋</span>
        </div>
        <div class="pbm-tray-grid" id="pbmTray"></div>
      </div>

      <div class="pbm-actions">
        <button class="btn btn-ghost" id="pbmAuto">一键取齐</button>
        <button class="btn btn-ghost" id="pbmClear">清空托盘</button>
        <button class="btn btn-primary btn-big" id="pbmConfirm" disabled>上桌开拆！</button>
      </div>
    </div>
  `),l=d.root||d.el;function o(){const M=l.querySelector("#pbmShelf"),m=l.querySelector("#pbmTray"),v=l.querySelector("#pbmCount"),g=l.querySelector("#pbmConfirm");!M||!m||(v.textContent=r.length,g.disabled=r.length<s,M.innerHTML=Array.from({length:i}).map((f,$)=>{const P=r.includes($),C=$>=c.length;return`
        <button class="pbm-shelf-bag ${P?"picked":""} ${C?"extra":""}" data-shelf-idx="${$}" ${P?"disabled":""} title="${P?"已拿入托盘":"点击放入托盘"}">
          <span class="psb-cat">${j(a,22)}</span>
          <span class="psb-num">#${$+1}</span>
          ${C?'<span class="psb-tag">备用</span>':""}
        </button>
      `}).join(""),m.innerHTML=Array.from({length:s}).map((f,$)=>{const P=r[$];return P!=null?`
          <button class="pbm-tray-slot filled" data-tray-slot="${$}" title="点击放回货架">
            <span class="pts-cat">${j(a,20)}</span>
            <span class="pts-num">#${P+1}</span>
            <span class="pts-back-tip">放回</span>
          </button>
        `:`
        <div class="pbm-tray-slot empty">
          <span class="pts-empty-dash">+待放入</span>
        </div>
      `}).join(""),M.querySelectorAll("[data-shelf-idx]").forEach(f=>{f.onclick=()=>{const $=Number(f.dataset.shelfIdx);if(!r.includes($)){if(r.length>=s){L(`已选满 ${s} 袋，直接点击「上桌开拆」吧！`);return}r.push($),y.tap(),o()}}}),m.querySelectorAll("[data-tray-slot]").forEach(f=>{f.onclick=()=>{const $=Number(f.dataset.traySlot);r.splice($,1),y.tap(),o()}}))}const u=l.querySelector("#pbmAuto");u&&(u.onclick=()=>{const M=[];for(let m=0;m<c.length;m++)M.push(m);for(let m=M.length-1;m>0;m--){const v=Math.floor(Math.random()*(m+1));[M[m],M[v]]=[M[v],M[m]]}r=M.slice(0,s).sort((m,v)=>m-v),y.cash(),o()});const b=l.querySelector("#pbmClear");b&&(b.onclick=()=>{r=[],y.tap(),o()});const B=l.querySelector("#pbmConfirm");B&&(B.onclick=()=>{if(r.length<s)return;y.cash();const M=[...r].sort((v,g)=>g-v),m=[];for(const v of M)v<(n.packed[a]||[]).length&&m.push(n.packed[a].splice(v,1)[0]);m.reverse(),t.trayBags=m,d.close(),e()}),o()}function Pn(t,e,n,a){const s=w(),c=t.cat,i=t.buyerName||"单主",r=s.trend.style&&nt(s.trend.style)||H.find(m=>m.cat===c)||H[0],d=H.filter(m=>m.cat===c&&(m.rarity==="rare"||m.rarity==="epic")),l=d.length>0?d[Math.floor(Math.random()*d.length)]:r,o=H.filter(m=>m.cat===c&&m.rarity==="legendary"),u=o.length>0?o[0]:H.find(m=>m.rarity==="legendary")||l,b=[{id:"trend",badge:"🔥 流量爆款",title:"推荐今日风向爆款",design:r,pitch:`主播：“单主快看！今天全网风向最火爆的就是【${r.name}】，戴出门回头率拉满！”`,reply:"哇！太懂我了，我就要这个！主播贴贴！"},{id:"rare",badge:"✨ 高级稀有",title:"推荐心仪高颜值稀有款",design:l,pitch:`主播：“单主手气通灵！主播直接推荐这款高颜值、细节拉满的精致稀有款【${l.name}】！”`,reply:`天呐颜值好高！一眼相中【${l.name}】！太幸运了！`},{id:"legend",badge:"👑 镇店传说",title:"主播宠粉·升级典藏传说款",design:u,pitch:`主播：“今天直播间排面给足！主播宠粉到底，直接给你提一件镇店传说【${u.name}】！”`,reply:"卧槽直接上传说？！主播大善人！今晚必须给直播间点赞十万次！"}],B=yt(`
    <div class="secret-dialogue-modal">
      <div class="sdm-header">
        <div class="sdm-crown">👑</div>
        <h3 class="m-title" style="color:var(--deep-wine-red);margin-bottom:4px;">欧气大爆发 · 抽到大隐藏！</h3>
        <p class="sdm-sub">
          与单主 <b>${i}</b> 正在直播间连线，请选择话术沟通自选款式：
        </p>
      </div>

      <div class="sdm-options">
        ${b.map((m,v)=>`
          <div class="sdm-card" data-opt="${v}">
            <div class="sdm-card-top">
              <span class="sdm-badge">${m.badge}</span>
              <b class="sdm-opt-title">${m.title}</b>
            </div>
            <div class="sdm-preview rc-${m.design.rarity}">
              <span class="sdm-icon">${j(m.design,22)}</span>
              <span class="sdm-name">${m.design.name}</span>
              <span class="sdm-rarity">（${J[m.design.rarity].name}）</span>
            </div>
            <p class="sdm-pitch">${m.pitch}</p>
            <button class="btn btn-primary sdm-choose-btn" data-choose="${v}">与单主沟通选此款</button>
          </div>
        `).join("")}
      </div>
    </div>
  `);(B.root||B.el).querySelectorAll("[data-choose]").forEach(m=>{m.onclick=()=>{const v=Number(m.dataset.choose),g=b[v];y.legendary(),B.close(),a(g.design,g.reply)}})}function qt(t){var d,l,o;const e=w();if(((l=(d=p==null?void 0:p.order)==null?void 0:d.trayBags)==null?void 0:l.length)>0&&p.order.cat&&(e.packed[p.order.cat]=[...e.packed[p.order.cat]||[],...p.order.trayBags],p.order.trayBags=[]),p.idx++,p.idx>=p.orders.length)return _t(t);p.order=p.orders[p.idx],p.ctx=gn(p.order);const n=p.order;if(n.type==="limited"){const u=n.item,b=nt(u.designId),B=_e.find(M=>M.key===u.gem);t.innerHTML=`
      <div class="order-card limited">
        <div class="oc-tag">限定专场</div>
        <div class="oc-buyer-bar">
          <span class="oc-buyer-badge">单主</span>
          <b class="oc-buyer-name">${n.buyerName||"VIP买家"}</b>
        </div>
        <div class="oc-limited">
          <span class="oc-lim-ic">💎</span>
          <div><b>${b.name}</b><span>镶嵌 ${B.name} · 绝版限定</span></div>
        </div>
        <div class="oc-price">直售价 <b>¥${u.price}</b></div>
        <div class="oc-btns">
          <button class="btn btn-primary btn-big" id="ocGo">上架售出</button>
          <button class="btn btn-ghost" id="ocSkip">下播</button>
        </div>
      </div>`,O(at.limited,3),y.rare(),t.querySelector("#ocGo").onclick=()=>{Ge(t)},t.querySelector("#ocSkip").onclick=()=>_t(t),Lt(t.querySelector(".order-card"));return}const a=n.cat===e.trend.cat,s=n.doublePrice?2:1,c=Math.round((Le+n.size*Ie)*(a?Ae:1)*s),i=(e.packed[n.cat]||[]).length,r=p.idx+(((o=p.orders[0])==null?void 0:o.type)==="limited"?0:1);if(i<n.size){const u=i===0;t.innerHTML=`
      <div class="order-card stockout-order ${n.doublePrice?"order-card-promo":""}">
        <div class="oc-tag ${n.doublePrice?"promo":a?"hot":""}">
          ${n.doublePrice?'<span class="oc-tag-promo">🔥投流推广单</span> · ':""}${n.held?'<span class="oc-tag-held">★保留单</span> · ':""}订单 ${r}${a?" · 命中风向 ×1.5":""}${n.doublePrice?" · 收益翻倍 ×2":""}
        </div>
        <div class="oc-buyer-bar">
          <span class="oc-buyer-badge ${n.doublePrice?"promo-buyer":""}">${n.doublePrice?"🔥推流贵宾":"单主"}</span>
          <b class="oc-buyer-name">${n.buyerName||"神秘顾客"}</b>
        </div>
        <div class="oc-main">
          <span class="oc-cat">${j(n.cat,30)}</span>
          <div class="oc-info">
            <b>${X[n.cat].name}盲袋 × ${n.size}</b>
            <span>保底 ${Ut} 袋 · 拆完统一对对碰</span>
            <div class="oc-stock empty">
              当前${X[n.cat].name}库存：<b>${i} 袋</b> <span class="oc-stock-badge">${u?"已缺货":"库存不足"}</span>
            </div>
          </div>
          <div class="oc-price">预估 <b class="${n.doublePrice?"promo-gold":""}">¥${c}</b></div>
        </div>
        <p class="oc-warn-tip">${u?"该品类盲袋已无库存！":`该品类盲袋库存不足（需要 ${n.size} 袋，现仅有 ${i} 袋）！`}可跳过此单，或花 ¥50 保留至下场直播进货后再拆。</p>
        <div class="oc-btns oc-btns-empty">
          <button class="btn btn-ghost" id="ocSkipOrder">跳过订单</button>
          <button class="btn btn-primary" id="ocHoldOrder" ${e.money<50?"disabled":""}>花 ¥50 保留到下场</button>
          <button class="btn btn-ghost" id="ocSkip">下播</button>
        </div>
      </div>`,t.querySelector("#ocSkipOrder").onclick=()=>{y.tap(),L(`已跳过 ${X[n.cat].name} 订单`),qt(t)},t.querySelector("#ocHoldOrder").onclick=()=>{if(e.money<50)return y.warn(),L("金币不足 ¥50，无法保留订单","warn");y.cash(),e.money-=50,e.heldOrders=e.heldOrders||[],e.heldOrders.push({type:"bags",cat:n.cat,size:n.size,lucky:n.lucky,held:!0,buyerName:n.buyerName}),xt(e),$t(t.querySelector("#ocHoldOrder")||t,"-¥50","#ffb3b3"),L("已花费 ¥50 将该订单保留至下一场直播！"),st(),qt(t)},t.querySelector("#ocSkip").onclick=()=>_t(t),Lt(t.querySelector(".order-card"));return}t.innerHTML=`
    <div class="order-card ${n.doublePrice?"order-card-promo":""}">
      <div class="oc-tag ${n.doublePrice?"promo":a?"hot":""}">
        ${n.doublePrice?'<span class="oc-tag-promo">🔥投流推广单</span> · ':""}${n.held?'<span class="oc-tag-held">★保留单</span> · ':""}订单 ${r}${a?" · 命中风向 ×1.5":""}${n.doublePrice?" · 收益翻倍 ×2":""}
      </div>
      <div class="oc-buyer-bar">
        <span class="oc-buyer-badge ${n.doublePrice?"promo-buyer":""}">${n.doublePrice?"🔥推流贵宾":"单主"}</span>
        <b class="oc-buyer-name">${n.buyerName||"神秘顾客"}</b>
      </div>
      <div class="oc-main">
        <span class="oc-cat">${j(n.cat,30)}</span>
        <div class="oc-info">
          <b>${X[n.cat].name}盲袋 × ${n.size}</b>
          <span>保底 ${Ut} 袋 · 拆完统一对对碰</span>
          <div class="oc-stock">
            当前${X[n.cat].name}库存：<b>${i} 袋</b>${i<n.size?' <span class="oc-stock-low">(少于订单需求)</span>':""}
          </div>
        </div>
        <div class="oc-price">预估 <b class="${n.doublePrice?"promo-gold":""}">¥${c}</b></div>
      </div>
      <div class="oc-btns">
        <button class="btn btn-primary btn-big" id="ocGo">接单备货</button>
        <button class="btn btn-ghost" id="ocSkip">下播</button>
      </div>
    </div>`,t.querySelector("#ocGo").onclick=()=>{An(n,()=>Fn(t))},t.querySelector("#ocSkip").onclick=()=>_t(t),Lt(t.querySelector(".order-card"))}function Fn(t){const e=p.order,n=w();t.innerHTML=`
    <div class="bag-area3">
      <section class="lv-cam">
        <div class="lv-tag">直播画面</div>
        <div class="live-feed-left" id="liveEventFeed"></div>
        <div class="live-feed-right" id="danmaku"></div>
        <div class="lv-active" id="lvActive"><div class="lv-hint">点下方盲袋开拆</div></div>
      </section>
      <section class="lv-show">
        <div class="lv-tag">展示</div>
        <div class="show-colors">
          <span class="oc-chip" title="拆到此色硬币本单多拆一袋">订单色 <i class="coin-dot sm" style="--cc:${S[e.lucky].hex}">${S[e.lucky].name}</i></span>
          <span class="oc-chip dim" id="lvLuckyColorChip" title="${S[n.trend.lucky].name}色硬币对碰：${S[n.trend.lucky].pair}">今日幸运色 <i class="coin-dot sm" style="--cc:${S[n.trend.lucky].hex}">${S[n.trend.lucky].name}</i> <span id="lvLuckyBuffText">${S[n.trend.lucky].pair}</span></span>
        </div>
        <div class="lv-mid">
          <div class="lv-box"><div class="lv-panel-title">首饰盒</div><div class="lv-box-items" id="lvBoxItems"><span class="lv-empty">空</span></div></div>
          <div class="lv-tray"><div class="lv-panel-title">木盘</div><div class="lv-tray-coins" id="lvTrayCoins"><span class="lv-empty">空</span></div></div>
        </div>
      </section>
      <section class="lv-pend">
        <div class="lv-tag">待拆</div>
        <div class="lv-queue" id="lvQueue"></div>
        <div class="lv-extra" id="lvExtra"></div>
      </section>
    </div>`;const a=t.querySelector("#lvQueue");for(let r=0;r<e.size;r++)a.appendChild(Mt(e,!1));const s=!p.streamStarted;if(s){p.streamStarted=!0;const r=Math.floor(Math.random()*2)+2;O(at.enter,r,150)}wt(`主播好！我来蹲我的${X[e.cat].name}盲袋啦！求大隐藏求对碰！`,s?900:300);const c=Math.floor(Math.random()*2)+3,i=s?1100:450;O(at.order,c,i)}function Mt(t,e,n=!1){const a=document.createElement("button");return a.className="bag ziplock"+(e?" bonus":"")+(n?" milk":""),a.innerHTML=`<div class="bag-body"><div class="bag-hang-hole"></div><div class="bag-zip-strip"></div><span class="bag-cat">${j(t.cat,20)}</span>${n?'<em class="bag-plus milk">🍼+1</em>':e?'<em class="bag-plus">+1</em>':""}</div>`,a.onclick=()=>Nn(a),a}function Nn(t){if(t.classList.contains("opening")||t.classList.contains("opened")||t.classList.contains("stockout"))return;const e=w(),n=p.order,a=p.ctx,s=document.getElementById("lvActive");if(!s||a.done)return;a.queue<=0&&(a.queue=1);const c=kn(e,n,a);if(!c)return;t.classList.add("opening"),p.heat++,Qt(),Vt();const i=t.cloneNode(!0);i.classList.remove("opening"),i.classList.add("moving"),t.style.visibility="hidden",s.innerHTML="",s.appendChild(i),y.tear(),setTimeout(()=>{i.classList.add("opened");const r=document.getElementById("lvQueue");if(c.slot==="stockout"){i.classList.add("stockout"),i.innerHTML='<div class="bag-body"><span class="bag-miss">缺货</span></div>',y.bad(),O(at.stockout,2),W("warn","缺货","缺货 · 评价 -2"),t.remove(),ee(r);return}t.remove();const d=J[c.design.rarity];i.innerHTML=`
      <div class="bag-reveal rc-${c.design.rarity}">
        <span class="br-ic">${j(c.design,20)}</span>
        <span class="br-name">${c.design.name}</span>
        <div class="br-meta">
          <i class="coin-dot" style="--cc:${S[c.coin].hex}">${S[c.coin].name}</i>
        </div>
      </div>
      <div class="bag-lucky-footer">
        <span class="br-lucky-val" title="盲袋随机欧气值">欧气 ${c.luckyVal||80}</span>
        ${c.isCrit?'<span class="br-crit-tag">★欧气暴击</span>':""}
        ${c.upgraded?'<span class="br-upgraded-tag">✨升级款</span>':""}
      </div>`,c.design.rarity==="legendary"?y.legendary():c.design.rarity==="epic"?y.rare():y.coin();const l=i.getBoundingClientRect();let o=!1;if(c.isCrit&&(W("bag","★ 欧气暴击！",`欧气值 ${c.luckyVal} · 单主追加小费 +¥10！`),wt("这袋欧气爆表！值了值了！给主播赏小费！",200),O(["欧气大暴击！","吸欧气吸欧气！","这手气绝了！"],2),$t(i,"+¥10 小费","#FFD98E"),y.cash(),o=!0),c.upgraded&&(W("rare","✨ 欧气升阶",`金光一闪！款式升级为 ${c.design.name}！`),O(["哇直接变异升级？！","主播手气神了！"],2),o=!0),(c.design.rarity==="epic"||c.design.rarity==="legendary")&&(kt(l.left+l.width/2,l.top+l.height/2,[d.color,"#FFF"],16),O(c.design.rarity==="legendary"?at.legendary:at.epic,2),W("rare",d.name,c.design.name),o=!0),c.styleHit&&(W("trend","爆款","风向款！粉丝 +1"),O(["风向款拆到了！","就是这个！买爆！"],2),o=!0),c.luckyHit){y.coin();const u=c.coin.startsWith("secret")?S[c.coin].name:`${S[c.coin].name}色`;W("bag","+1袋",`订单色加持 · ${u}`),wt("哇！我的订单幸运色！加拆一袋！",200),O(at.lucky,2),o=!0,r&&r.appendChild(Mt(n,!0))}if(c.coin==="secret_s"&&(y.coin(),kt(l.left+l.width/2,l.top+l.height/2,["#C2D1E5","#FFFFFF"],14),W("bag","✨ 小隐藏","小隐藏加持 · 加拆 1 袋盲袋！"),wt("哇啊啊啊出小隐藏了！！加拆一袋！太欧啦！",150),O(at.secret_s,2,250),o=!0,r&&r.appendChild(Mt(n,!0))),c.coin==="secret_b"){y.legendary(),kt(l.left+l.width/2,l.top+l.height/2,["#FF5EC8","#FFD98E","#FFFFFF"],22),W("rare","👑 大隐藏！","抽中大隐藏 · 开启单主自选款式沟通！"),wt("天呐是大隐藏！！！我抽到大隐藏了！求主播自选！",150),O(at.secret_b,3,200),o=!0,te(),we(c.coin),Pn(n,a,c,(u,b)=>{c.design=u;const B=a.opened[a.opened.length-1];B&&(B.design=u),te(),y.legendary(),wt(b,50),W("rare","自选达成",`单主 ${n.buyerName||""} 确定选择【${u.name}】！`),$t(s,"大隐藏自选达成！","#FF5EC8"),O(at.secret_b,2,300),p.totalBagsOpened=(p.totalBagsOpened||0)+1,p.hasRandomEvent&&!p.randomEventTriggered&&(p.totalBagsOpened>=2||Math.random()<.35)&&(p.randomEventTriggered=!0,ht.push(setTimeout(()=>{Se(p.randomEventIsGain,s)},450))),ee(r)});return}!o&&Math.random()<.8&&O(at.generic,1),te(),we(c.coin),p.totalBagsOpened=(p.totalBagsOpened||0)+1,p.hasRandomEvent&&!p.randomEventTriggered&&(p.totalBagsOpened>=2||Math.random()<.35)&&(p.randomEventTriggered=!0,ht.push(setTimeout(()=>{Se(p.randomEventIsGain,i)},450))),ee(r)},260)}function te(){const t=document.getElementById("lvBoxItems");if(!t)return;const e=p.ctx,n={},a=[];for(const s of e.opened)s.design&&(n[s.design.id]||(n[s.design.id]={d:s.design,n:0,style:!1},a.push(s.design.id)),n[s.design.id].n++,On()===s.design.id&&(n[s.design.id].style=!0));t.innerHTML=a.length===0?'<span class="lv-empty">空</span>':a.map(s=>{const c=n[s];return`<span class="box-jewel rc-${c.d.rarity}${c.style?" style-hit":""}">${j(c.d,14)}${c.d.name}${c.n>1?` ×${c.n}`:""}</span>`}).join(""),t.scrollTop=t.scrollHeight}function On(){return w().trend.style}function we(t){var a;const e=document.getElementById("lvTrayCoins");if(!e)return;(a=e.querySelector(".lv-empty"))==null||a.remove();const n=document.createElement("span");n.className="tray-coin",n.dataset.c=t,n.innerHTML=`<i class="coin-dot" style="--cc:${S[t].hex}">${S[t].name}</i>`,e.appendChild(n),Lt(n),e.scrollTop=e.scrollHeight}function Dn(){var r,d;const t=document.getElementById("lvLuckyColorChip"),e=document.getElementById("lvLuckyBuffText");if(!t||!e)return;const n=w(),a=(r=n==null?void 0:n.trend)==null?void 0:r.lucky,s=S[a];if(!s)return;const i=(((d=p==null?void 0:p.ctx)==null?void 0:d.buffs)||[]).filter(l=>l.key===a).length;i>0?(t.classList.remove("dim"),t.classList.add("active-buff"),e.innerHTML=`${s.pair} <b class="buff-count">(已生效×${i})</b>`):(t.classList.add("dim"),t.classList.remove("active-buff"),e.textContent=s.pair)}function je(){var n,a;const t=document.getElementById("lvTrayCoins");if(!t)return;t.innerHTML="";let e=0;for(const s of V){const c=((a=(n=p==null?void 0:p.ctx)==null?void 0:n.tally)==null?void 0:a[s])||0;e+=c;for(let i=0;i<c;i++){const r=document.createElement("span");r.className="tray-coin",r.dataset.c=s,r.innerHTML=`<i class="coin-dot" style="--cc:${S[s].hex}">${S[s].name}</i>`,t.appendChild(r)}}if(e===0){const s=document.createElement("span");s.className="lv-empty",s.textContent="空",t.appendChild(s)}}function ee(t){const e=p.ctx;if(!t||e.done||t.querySelectorAll(".bag:not(.opened):not(.stockout)").length>0)return;if(e.queue>0){for(let s=0;s<e.queue;s++)t.appendChild(Mt(p.order,!0));return}let a=0;for(const s of V)a+=Math.floor((e.tally[s]||0)/2);if(a>0){zn(t);return}Re(t)}function zn(t){const e=p.ctx,n=w(),a=()=>{let k=0;for(const E of V)k+=Math.floor((e.tally[E]||0)/2);return k},s=a();if(s<=0){Re(t);return}const c=[];let i=0;for(const k of V){const E=e.tally[k]||0;for(let Y=0;Y<E;Y++)c.push({id:`tm_c_${i++}`,key:k,matched:!1,x:0,y:0})}const r=document.createElement("div");r.className="tray-match-overlay",r.id="trayMatchOverlay",r.innerHTML=`
    <div class="tray-match-panel">
      <div class="tray-match-header">
        <div class="tm-title-wrap">
          <span class="tm-title">对对碰</span>
          <span class="tm-sub" id="tmSubHint">拖动同色硬币凑对（还可碰 <b id="tmRemainPairs">${s}</b> 对）</span>
        </div>
        <button class="btn btn-ghost btn-mini" id="tmQuickMatch" title="自动配对所有同色硬币">快速全碰</button>
      </div>
      <div class="tray-plate" id="trayPlate"></div>
    </div>
  `,document.body.appendChild(r);const d=r.querySelector("#trayPlate"),l=c.length,o=4,u=44,b=14,B=14,M=Math.ceil(l/o),m=M*u+Math.max(0,M-1)*B,v=Math.max(210,m+36);d.style.minHeight=`${v}px`;const g=d.clientWidth||344,f=Math.max(v,d.clientHeight||v);c.forEach((k,E)=>{const Y=Math.floor(E/o),Q=E%o,I=Y===M-1&&l%o!==0?l%o:o,h=I*u+(I-1)*b,D=(g-h)/2,F=Math.max(18,(f-m)/2);k.x=Math.round(D+Q*(u+b)),k.y=Math.round(F+Y*(u+B))});const $=[];let P=null,C=null,R=!1;const G=()=>{if(C){const k=document.getElementById(C.id);k==null||k.classList.remove("match-candidate"),C=null}},it=(k,E)=>{if(k.matched||E.matched)return;k.matched=!0,E.matched=!0,G();const Y=k.key;$.push(Y);const{isLucky:Q}=$n(n,p.order,e,Y),I=document.getElementById(k.id),h=document.getElementById(E.id),D=(k.x+E.x)/2,F=(k.y+E.y)/2;I&&(I.style.left=`${D}px`,I.style.top=`${F}px`,I.classList.add("matching")),h&&(h.style.left=`${D}px`,h.style.top=`${F}px`,h.classList.add("matching")),y.coin(),Q&&y.legendary(),$t(d,Q?"✨ 幸运对碰！+1袋":"✨ 对对碰！+1袋",S[Y].hex,!0),Q?O(["幸运色碰成了！","欧气爆发！","专属buff生效！"],2):O(at.pair,1),setTimeout(()=>{I==null||I.remove(),h==null||h.remove()},540);const _=a(),K=document.getElementById("tmRemainPairs");if(K&&(K.textContent=_),e.heatAdd&&(p.heat+=e.heatAdd,e.heatAdd=0,Qt()),Dn(),_===0&&!R){R=!0;const Z=document.getElementById("tmSubHint");Z&&(Z.innerHTML='<span class="tm-finish-text">🎉 碰完啦！正在结算...</span>');const x=document.getElementById("tmQuickMatch");x&&(x.disabled=!0),setTimeout(()=>{r.classList.add("fade-out"),setTimeout(()=>{r.remove(),je(),Hn($,t)},220)},520)}};c.forEach(k=>{const E=document.createElement("div");E.className="tm-coin",E.id=k.id,E.dataset.id=k.id,E.dataset.key=k.key,E.style.left=`${k.x}px`,E.style.top=`${k.y}px`,E.style.setProperty("--coin-color",S[k.key].hex),E.innerHTML=`
      <div class="tm-coin-inner">
        <span class="tm-coin-tint"></span>
      </div>
    `,d.appendChild(E);let Y=0,Q=0;E.onpointerdown=I=>{if(k.matched||R)return;P=k;try{E.setPointerCapture(I.pointerId)}catch(D){}const h=d.getBoundingClientRect();Y=I.clientX-h.left-k.x,Q=I.clientY-h.top-k.y,E.classList.add("dragging"),y.tap()},E.onpointermove=I=>{if(P!==k||k.matched)return;const h=d.getBoundingClientRect(),D=h.width-44,F=h.height-44;let _=I.clientX-h.left-Y,K=I.clientY-h.top-Q;_=Math.max(4,Math.min(D,_)),K=Math.max(4,Math.min(F,K)),k.x=_,k.y=K,E.style.left=`${_}px`,E.style.top=`${K}px`;const Z={x:k.x+22,y:k.y+22};let x=null,dt=1/0;for(const U of c){if(U===k||U.matched||U.key!==k.key)continue;const St={x:U.x+22,y:U.y+22},A=Math.hypot(Z.x-St.x,Z.y-St.y);A<54&&A<dt&&(dt=A,x=U)}if(x!==C&&(G(),x)){C=x;const U=document.getElementById(x.id);U==null||U.classList.add("match-candidate")}x&&dt<34&&!k.matched&&!x.matched&&it(k,x)},E.onpointerup=E.onpointercancel=I=>{if(P===k){try{E.releasePointerCapture(I.pointerId)}catch(h){}E.classList.remove("dragging"),P=null,C&&!C.matched&&!k.matched&&it(k,C),G()}}});const rt=r.querySelector("#tmQuickMatch");rt&&(rt.onclick=()=>{rt.disabled=!0;const k=()=>{if(R)return;let E=null;for(const Y of V){const Q=c.filter(I=>!I.matched&&I.key===Y);if(Q.length>=2){E=[Q[0],Q[1]];break}}E&&(it(E[0],E[1]),setTimeout(k,260))};k()})}function Hn(t,e){const n=p.ctx,s=w().trend.lucky,c=V.every(l=>!n.tally[l]);c&&(n.queue+=3);const i=t.filter(l=>l===s),r=t.map((l,o)=>{const u=l===s;return`
    <div class="pair-row ${u?"is-lucky":""}">
      <span class="pair-idx">${o+1}</span>
      <i class="coin-dot sm" style="--cc:${S[l].hex}">${S[l].name}</i>
      <span class="pair-eff ${u?"is-lucky":""}">${u?`✨ 幸运色触发：${S[l].pair} + 加拆1袋`:"加拆 1 袋"}</span>
    </div>`}).join(""),{close:d}=yt(`
    <h3 class="m-title">对对碰 × ${t.length}</h3>
    <div class="pair-list">${r}</div>
    ${c?'<div class="clear-banner">清盘！另加三袋盲袋</div>':""}
    <p class="pair-note">本轮加拆 ${n.queue} 袋${i.length?`；触发 ${i.length} 次今日幸运色 buff！`:""}${c?"":"；配对成功的硬币已收走，没凑成对的原地留着等下一轮"}</p>
    <button class="btn btn-primary btn-big" id="pairGo">继续拆袋</button>
  `,{closable:!1});y.pair(),(c||i.length)&&y.legendary(),O(at.pair,3),i.length&&O(["幸运色碰成了！","欧气爆发！","专属buff生效！"],2),c&&O(["清盘了！！","木盘都被碰空了！","这就是欧皇吗"],3),document.getElementById("pairGo").onclick=()=>{y.tap(),d(),je();const l=u=>u.startsWith("secret")?S[u].name:`${S[u].name}色`;i.length&&W("buff","幸运对碰",`${l(s)} · ${S[s].pair}`);const o=[...new Set(t.map(l))].join("、");W("pair","对碰",`${o} · 加拆 ${n.queue} 袋`),c&&W("buff","清盘","另加三袋！");for(let u=0;u<n.queue;u++)e.appendChild(Mt(p.order,!0))}}function Re(t){const e=document.getElementById("lvExtra"),n=p.ctx;if(!e||(e.innerHTML="",n.queue>0))return;if(n.opened.length<Ut){const r=document.createElement("button");r.className="btn btn-ghost",r.id="lvGuaranteeBtn",r.textContent=`补拆一袋（保底 ${n.opened.length}/${Ut}）`,r.onclick=()=>{p.ctx.queue++,t.appendChild(Mt(p.order,!0)),y.tap(),W("bag","保底","保底机制 · 补拆一袋"),e.innerHTML=""},e.appendChild(r);return}const a=document.createElement("div");a.className="lv-extra-actions";const s=n.milkCount||0,c=document.createElement("button");c.className="btn btn-milk btn-big",c.id="lvMilkBtn",c.innerHTML=`🍼 奶一口${s>0?` <span class="milk-badge">×${s}</span>`:'<span class="milk-sub">+1袋</span>'}`,c.title="为主播的单主额外加拆一袋盲袋！",c.onclick=()=>{n.milkCount=(n.milkCount||0)+1,p.ctx.queue++;const r=Mt(p.order,!0,!0);t.appendChild(r),y.fans(),p.heat=(p.heat||0)+2,xt(w()),W("buff","奶一口",`主播给单主 ${p.order.buyerName||"贵宾"} 豪横奶了一袋！`),$t(r,"🍼 奶一口 +1袋！","#FF7EB6",!0),wt(It(["哇塞！！谢谢主播给我奶一口！！爱你！","主播太好了吧！看我这袋能不能出大隐藏！","啊啊啊被主播奶到了！这次必出金！","呜呜呜感恩主播！爱住这个直播间了！"]),150),O(["主播大气！","给单主奶活了！","格局打开了！","我也想要主播奶一口呜呜","再来一袋冲冲冲！","看好这袋，肯定能对碰！"],2,300),e.innerHTML="";const d=document.getElementById("lvActive");d&&(d.innerHTML='<div class="lv-hint milk-hint">🍼 奶了一袋！点下方盲袋开拆</div>')};const i=document.createElement("button");i.className="btn btn-primary btn-big",i.id="lvDoneBtn",i.textContent="完成订单",i.onclick=()=>Ge(document.getElementById("stage")),a.appendChild(c),a.appendChild(i),e.appendChild(a)}function Ge(t){var d;const e=w(),n=Oe(e,p.order,p.ctx);y.cash(),xt(e),Vt(),p.order.type!=="limited"&&p.order.cat===e.trend.cat&&O(["风向单品！买爆！","果然是今天的顶流"],2);const a={};for(const l of p.ctx.opened)l.design&&(a[l.design.id]||(a[l.design.id]={d:l.design,n:0}),a[l.design.id].n++);const s=Object.values(a),c={};for(const l of p.ctx.opened)l.coin&&(c[l.coin]=(c[l.coin]||0)+1);const i=p.ctx.stockouts,{close:r}=yt(`
    <h3 class="m-title">订单完成！</h3>
    <div class="harvest">
      <div class="hv-sec"><label>本单收获（${s.reduce((l,o)=>l+o.n,0)} 件首饰）</label>
        <div class="hv-jewels">
          ${s.map(l=>`<span class="box-jewel rc-${l.d.rarity}">${j(l.d.cat,14)}${l.d.name}${l.n>1?` ×${l.n}`:""}</span>`).join("")||'<span class="empty-hint">一无所获…</span>'}
        </div>
      </div>
      <div class="hv-sec"><label>硬币去向</label>
        <div class="hv-coins">
          ${Object.entries(c).map(([l,o])=>`<span class="hv-coin"><i class="coin-dot sm" style="--cc:${S[l].hex}">${S[l].name}</i>×${o}</span>`).join("")||'<span class="empty-hint">无</span>'}
          ${i?`<span class="hv-coin miss">缺货 ×${i}</span>`:""}
        </div>
      </div>
      ${(p.ctx.buffs||[]).length?`<div class="hv-sec"><label>触发 buff</label>
        <div class="hv-jewels">${p.ctx.buffs.map(l=>`<span class="oc-chip buff">✨ ${l.name}·${l.desc}</span>`).join("")}</div>
      </div>`:""}
      <div class="hv-result">
        <div><span>原本金额</span><b class="hv-base">¥${(d=n.base)!=null?d:n.price}</b></div>
        ${n.doublePrice?'<div><span>投流加成</span><b class="hv-promo">双倍价格 ×2</b></div>':""}
        ${n.buffPart?`<div><span>buff 加成</span><b class="hv-fans">+¥${n.buffPart}</b></div>`:""}
        <div><span>营收</span><b class="hv-earn">+¥${n.price}</b></div>
        <div><span>粉丝</span><b class="hv-fans">+${n.fans}</b></div>
        ${p.ctx.pairs?`<div><span>对对碰</span><b class="hv-base">${p.ctx.pairs} 次</b></div>`:""}
        ${p.ctx.milkCount?`<div><span>主播奶袋</span><b class="hv-milk">🍼 ${p.ctx.milkCount} 袋</b></div>`:""}
      </div>
      <button class="btn btn-primary btn-big" id="hvNext">下一单</button>
    </div>`,{closable:!1});document.getElementById("hvNext").onclick=()=>{y.tap(),r(),qt(t)},kt(window.innerWidth/2,window.innerHeight/2.6,["#FFD98E","#FF7EB6","#7DE2D1"],24)}function _t(t){var n,a;const e=w();if(((a=(n=p==null?void 0:p.order)==null?void 0:n.trayBags)==null?void 0:a.length)>0&&p.order.cat&&(e.packed[p.order.cat]=[...e.packed[p.order.cat]||[],...p.order.trayBags],p.order.trayBags=[]),e.streamsLeft=Math.max(0,e.streamsLeft-1),p&&p.heat>e.fans){const s=Math.round(e.fans*nn);e.fans+=s,e.stats.heatBonus=(e.stats.heatBonus||0)+s,xt(e),L(`热度破圈！全直播间涨粉 +${s}`),y.fans()}t.innerHTML='<div class="live-intro"><div class="li-ic">🌙</div><b>下播啦！</b><span>来看看今天的战果</span></div>',y.cash(),ht.push(setTimeout(()=>{e.stats&&(e.stats._res=null),bt({screen:"settle"}),st()},1200))}function qn(t){const e=w();e.stats||(e.stats=Fe());let n=e.stats._res;n||(n=Sn(e,{isLastStream:e.streamsLeft<=0}),e.stats._res=n,st());const a=n.level,s="★".repeat(a.stars)+"☆".repeat(5-a.stars),c=[...a.comments].sort(()=>Math.random()-.5).slice(0,2),i=Object.values(e.packed).reduce((d,l)=>d+l.length,0),r=e.streamsLeft>0;t.innerHTML=`
    <div class="settle">
      <h2 class="st-title">第 ${e.day} 天 · 下播结算</h2>
      <p class="st-sub">今日第 ${jt-e.streamsLeft} 场 · 还可播 ${e.streamsLeft} 场</p>
      <div class="st-card">
        <div class="st-row"><span>订单原本金额</span><b>¥${e.stats.earnBase||0}</b></div>
        <div class="st-row"><span>buff 加成</span><b class="st-fans">+¥${e.stats.earnBuff||0}</b></div>
        <div class="st-row"><span>总营收</span><b class="st-earn">¥${e.stats.earn}</b></div>
        <div class="st-row"><span>累计订单</span><b>${e.stats.ordersDone} 单 · 售出 ${e.stats.bagsSold} 袋</b></div>
        <div class="st-row"><span>对对碰 / 幸运色</span><b>${e.stats.pairs} 次 / ${e.stats.luckyHits} 次</b></div>
        ${e.stats.bestPull?`<div class="st-row"><span>最佳出货</span><b style="color:${J[e.stats.bestPull.rarity].color}">${e.stats.bestPull.name}</b></div>`:""}
        ${e.stats.stockouts?`<div class="st-row warn"><span>缺货</span><b>${e.stats.stockouts} 次</b></div>`:""}
      </div>
      <div class="st-card eval">
        <div class="st-eval-head"><span class="st-stars">${s}</span><b>${a.name}</b></div>
        ${c.map(d=>`<p class="st-comment">「${d}」</p>`).join("")}
      </div>
      <div class="st-card">
        <div class="st-row"><span>今日累计涨粉</span><b class="st-fans">+${e.stats.fansToday}</b></div>
        ${e.stats.heatBonus?`<div class="st-row"><span>热度打榜</span><b class="st-fans">+${e.stats.heatBonus}</b></div>`:""}
        ${n.fanBonus>0?`<div class="st-row"><span>好评加成</span><b class="st-fans">+${n.fanBonus}</b></div>`:""}
        <div class="st-row"><span>当前粉丝</span><b>${e.fans}</b></div>
      </div>
      ${n.mercy?'<p class="st-mercy">粉丝心疼你，打赏了 ¥150 快去进货吧</p>':""}
      <div class="st-actions">
        ${r?`<button class="btn btn-primary btn-big" id="stMore">继续直播（剩 ${e.streamsLeft} 场）</button>`:""}
        <button class="btn ${r?"btn-ghost":"btn-primary btn-big"}" id="stNext">下一天</button>
      </div>
      ${i>0?`<p class="st-note">还有 ${i} 袋没卖完${r?"，继续播接着卖":""}</p>`:""}
    </div>`,r&&(t.querySelector("#stMore").onclick=()=>{y.tap(),bt({screen:"day",dayTab:"pack"}),st()}),t.querySelector("#stNext").onclick=()=>{y.tap(),De(e),bt({screen:"day",dayTab:"shop"}),st()}}const T={day:0,cat:null,counts:{},coins:{}},Xt=new Set,ct={designs:!0,coins:!0};function jn(t){var i;const e=w();e.dayTab==="gem"&&(e.dayTab="shop"),T.day!==e.day&&(T.day=e.day,T.cat=null,T.counts={},T.coins={},ct.designs=!0,ct.coins=!0),(!Array.isArray(e.shop)||e.shop.length!==10)&&(e.shop=Pt()),e.shop.forEach(r=>{r&&r.tier!=="SSS"&&(r.tier="SSS")}),e.trend.style||(e.trend.style=Ht(e,e.trend.cat)),e.trend.saleStyle||(e.trend.saleStyle=pe(e,e.trend.cat,e.trend.style)),e.trend.saleDiscount||(e.trend.saleDiscount=.5);const n=lt.reduce((r,d)=>r+(e.packed[d]||[]).length,0),a=e.trend.style?nt(e.trend.style).name:null,s=e.trend.style&&e.codex.includes(e.trend.style),c=a?s?`「${a}」`:`【${a}】（未解锁）`:"款式待解锁";t.innerHTML=`
    <div class="wind-banner">
      <div class="wind-head"><span class="wind-tag">今日风向</span>
        <span class="wind-cat"> ${j(e.trend.cat,16)} ${X[e.trend.cat].name}</span>
        <span class="wind-style"> ${c}</span>
        <span class="wind-lucky">幸运色 <i class="coin-dot sm" style="--cc:${S[e.trend.lucky].hex}">${S[e.trend.lucky].name}</i></span>
      </div>
      <p class="wind-line">${sn[e.trend.cat]} 命中${X[e.trend.cat].name}订单营收 ×1.5；拆中「${a||"风向款式"}」每件粉丝 +1${a&&!s?"（先去把这款开出来！）":""}！</p>
    </div>
    <nav class="tabs">
      <button data-tab="shop" class="${e.dayTab==="shop"?"on":""}">进货</button>
      <button data-tab="pack" class="${e.dayTab==="pack"?"on":""}">装袋</button>
      <button data-tab="codex" class="${e.dayTab==="codex"?"on":""}">图鉴</button>
      
    </nav>
    <div class="tab-body" id="tabBody"></div>
    <div class="day-bottom">
      <span class="db-info">已装袋 <b>${n}</b> 袋${(i=e.heldOrders)!=null&&i.length?` · 保留单 <b>${e.heldOrders.length}</b>`:""}</span>
      <button class="btn btn-primary btn-live" data-act="live" ${n===0?"disabled":""}>开播${e.streamsLeft<jt?`（剩 ${e.streamsLeft} 场）`:""}</button>
      <button class="btn btn-ghost btn-nextday" data-act="nextday">下一天</button>
    </div>`,t.querySelectorAll(".tabs button").forEach(r=>{r.onclick=()=>{y.tap(),bt({dayTab:r.dataset.tab})}}),t.querySelector('[data-act="live"]').onclick=()=>Tn(),t.querySelector('[data-act="nextday"]').onclick=()=>Rn(e),ut(t.querySelector("#tabBody"))}function Rn(t){y.tap();const{close:e}=yt(`
    <h3 class="m-title">进入下一天？</h3>
    <p class="nd-note">未卖完的盲袋会保留到明天；风向与今日盲盒将刷新。</p>
    <div class="nd-btns">
      <button class="btn btn-ghost" id="ndCancel">留在当天</button>
      <button class="btn btn-primary" id="ndOk">确认</button>
    </div>`,{closable:!0});document.getElementById("ndCancel").onclick=()=>{y.tap(),e()},document.getElementById("ndOk").onclick=()=>{y.buy(),e(),De(t),bt({screen:"day",dayTab:"shop"}),st()}}function ut(t){const e=w();e.dayTab==="shop"?Me(t):e.dayTab==="pack"?Xn(t):e.dayTab==="codex"?Kn(t):Me(t)}function Me(t){var M;const e=w(),n=e.shop||[],a=n.map((m,v)=>pt(et({},m),{idx:v})).filter(m=>!m.sold),s=a.length,c=a.reduce((m,v)=>m+(v.price||50),0);e.money>=50&&s>0;const i=s>0&&e.money>=c,r=e.money>=50,d=n.map((m,v)=>{const g=m.price||50,f=e.money>=g;return m.sold?`
        <div class="wood-slot sold">
          <div class="wood-slot-pedestal">
            <div class="wood-sold-stamp">已售出</div>
          </div>
          <div class="wood-box-price is-sold">¥${g}</div>
          <button class="btn btn-mini wood-btn-buy is-sold-btn" disabled>已售出</button>
        </div>`:`
      <div class="wood-slot" data-offer="${v}">
        <div class="wood-box-display">
          <div class="wood-rect-box"></div>
        </div>
        <button class="btn btn-mini wood-btn-buy ${f?"btn-primary":"wood-btn-gray"}" data-offer="${v}" ${f?"":"disabled"}>
          ${f?"50":"余额不足"}
        </button>
      </div>`}).join(""),l=lt.map(m=>{const v=H.filter(f=>f.cat===m&&f.rarity!=="limited"&&e.codex.includes(f.id));return v.length===0?"":(v.sort((f,$)=>{var R,G,it,rt;const P=(f.id===((R=e.trend)==null?void 0:R.saleStyle)?2:0)+(f.id===((G=e.trend)==null?void 0:G.style)?1:0);return($.id===((it=e.trend)==null?void 0:it.saleStyle)?2:0)+($.id===((rt=e.trend)==null?void 0:rt.style)?1:0)-P}),`<div class="restock-cat ${Xt.has(m)?"":"collapsed"}" data-cat-id="${m}">
      <div class="restock-head" data-toggle-cat="${m}">
        <span class="rc-head-title">
          ${j(m,18)}
          <b>${X[m].name}补货</b>
        </span>
        <span class="rc-head-toggle">
          <span>${v.length} 款</span>
          <i class="rc-toggle-arrow">▼</i>
        </span>
      </div>
      <div class="restock-list">
        ${v.map(f=>{var it,rt;const $=J[f.rarity].unitPrice,P=f.id===((it=e.trend)==null?void 0:it.style),C=e.trend&&e.trend.saleStyle===f.id,R=((rt=e.trend)==null?void 0:rt.saleDiscount)||.5,G=C?Math.max(1,Math.round($*R)):$;return`<div class="restock-row ${P?"row-trend":""} ${C?"row-sale":""}">
            <span class="rr-ic" style="color:${J[f.rarity].color};display:inline-flex;align-items:center;">${j(f,16)}</span>
            <div class="rr-name-wrap">
              <span class="rr-name">${f.name}</span>
              ${P?'<span class="rr-badge-trend">风向款</span>':""}
              ${C?'<span class="rr-badge-sale">今日特价 5折</span>':""}
            </div>
            <span class="rr-stock">库存 ${e.stock[f.id]||0}</span>
            <span class="rr-price">
              ${C?`<del class="rr-old-price">¥${$}</del><b class="rr-sale-price">¥${G}</b>`:`¥${G}`}
            </span>
            <button class="btn btn-mini" data-buy="${f.id}" data-n="1" ${e.money<G?"disabled":""}>+1</button>
            <button class="btn btn-mini" data-buy="${f.id}" data-n="5" ${e.money<G*5?"disabled":""}>+5</button>
          </div>`}).join("")}
      </div>
    </div>`)}).join(""),o=(M=e.trend)!=null&&M.saleStyle?nt(e.trend.saleStyle):null;t.innerHTML=`
    <!-- 盲盒展架 -->
    <div class="wood-shelf-rack">
      <div class="wood-rack-header">
        <div class="wood-title-sign">
          <span class="wood-sign-text">盲盒</span>
        </div>
        <div class="wood-header-actions">
          <button class="btn btn-mini wood-btn-refresh ${r?"":"wood-btn-gray"}" id="woodRefreshShelf" ${r?"":"disabled"} title="花费 ¥50 重新生成整架 10 盒盲盒">
            刷新货架 ¥50
          </button>
          <button class="btn btn-mini ${i?"btn-primary":"wood-btn-gray"}" id="woodBuyAll" ${i?"":"disabled"} title="一键购买当前货架所有在售盲盒">
            一键购买${s>0?` (¥${c})`:" (已售空)"}
          </button>
        </div>
      </div>

      <!-- 层板陈列区 -->
      <div class="wood-rack-body">
        <div class="wood-slots-grid">
          ${d}
        </div>
        <div class="wood-rack-footer">
          <span class="wood-stock-tag">在售 <b>${s}</b> / 10 盒</span>
        </div>
      </div>
    </div>

    <!-- 款式补货 -->
    <div class="restock-header-bar">
      <h4 class="sec-title" style="margin-bottom:0;">款式补货</h4>
      ${o?`
      <div class="restock-trend-hint">
        <span>今日特价【<b class="text-sale">${o.name} 5折</b>】</span>
      </div>`:""}
    </div>
    <div class="restock">${l||'<p class="empty-hint">还没有解锁任何款式，先抽几个盲盒吧</p>'}</div>`;const u=t.querySelector("#woodRefreshShelf");u&&(u.onclick=()=>{if(e.money<50)return L("余额不足，刷新货架需 ¥50","warn");e.money-=50,e.shop=Pt(),y.tear(),y.coin(),L("已消耗 ¥50 刷新整个盲盒货架！","good"),Ft()});const b=t.querySelector("#woodBuyAll");b&&(b.onclick=()=>{const m=(e.shop||[]).map((g,f)=>pt(et({},g),{idx:f})).filter(g=>!g.sold);if(m.length===0)return L("当前货架盲盒已全部售空，可花 ¥50 刷新货架！","info");const v=m.reduce((g,f)=>g+(f.price||50),0);if(e.money<v)return L(`余额不足，一键购买全架需 ¥${v}`,"warn");Gn(m)});const B=t.querySelector("#woodRandomDraw");B&&(B.onclick=()=>{const m=(e.shop||[]).map((g,f)=>pt(et({},g),{idx:f})).filter(g=>!g.sold);if(m.length===0)return L("今日盲盒架已售空，请花 ¥50 刷新或明天再来！","info");if(e.money<50)return L("钱不够啦，单抽需 ¥50","warn");const v=m[Math.floor(Math.random()*m.length)];Be(v.cat,v.tier,v.idx)}),t.querySelectorAll(".wood-slot:not(.sold), .wood-btn-buy:not(.is-sold-btn)").forEach(m=>{m.onclick=v=>{v.stopPropagation();const g=Number(m.dataset.offer),f=e.shop[g];if(!(!f||f.sold)){if(e.money<(f.price||50))return L("钱不够啦，单抽需 ¥50","warn");Be(f.cat,f.tier,g)}}}),t.querySelectorAll("[data-toggle-cat]").forEach(m=>{m.onclick=v=>{v.stopPropagation();const g=m.dataset.toggleCat,f=m.closest(".restock-cat");Xt.has(g)?(Xt.delete(g),f==null||f.classList.add("collapsed")):(Xt.add(g),f==null||f.classList.remove("collapsed")),y.tap()}}),t.querySelectorAll("[data-buy]").forEach(m=>{m.onclick=()=>{if(!fn(e,m.dataset.buy,Number(m.dataset.n)).ok)return L("钱不够啦","warn");y.buy(),Ft()}})}function Gn(t){const e=w(),n=t.reduce((d,l)=>d+(l.price||50),0);if(e.money<n)return L(`余额不足，一键购买需 ¥${n}`,"warn");const a=[];let s=0;for(const d of t){const l=Ne(e,d.cat,d.tier);l.ok&&(d.idx!=null&&e.shop[d.idx]&&(e.shop[d.idx].sold=!0),l.items.forEach(o=>{a.push(pt(et({},o),{cat:d.cat})),o.isNew&&s++}))}const c=t.length,{close:i}=yt(`
    <div class="boxstage boxstage-multi">
      <div class="bm-modal-title">✨ 一键全购！连拆 ${c} 盒盲盒...</div>
      <div class="box-stage-wrap">
        <div class="box3d bm-mystery-3d-box" id="box3d">
          <div class="bm-modal-rect-box"></div>
        </div>
        <div class="box-reveal-banner" id="boxRevealBanner" style="display:none;"></div>
      </div>
      <div class="box-items box-items-multi" id="boxItems"></div>
      <button class="btn btn-primary" id="boxOk" style="visibility:hidden">全部收下并入库</button>
    </div>`,{closable:!1}),r=document.getElementById("box3d");setTimeout(()=>{r.classList.add("shaking"),y.tap()},60),setTimeout(()=>{r.classList.remove("shaking"),r.classList.add("opened");const d=r.getBoundingClientRect();kt(d.left+d.width/2,d.top+d.height/2,["#FFD98E","#FF7EB6","#7DE2D1","#C77DFF"],36),y.tear();const l=document.getElementById("boxRevealBanner");l&&(l.style.display="flex",l.innerHTML=`<span class="reveal-text">大丰收！共拆出 <b>${a.length} 件</b> 饰品${s>0?`（包含 <b style="color:var(--pink)">${s} 款新品</b>）`:""}！</span>`);const o=document.getElementById("boxItems");let u=!1;a.forEach((b,B)=>{const M=document.createElement("div");M.className="box-item",M.innerHTML=`${Jt(b.design)}${b.isNew?'<span class="new-badge">NEW</span>':""}
        <span class="grant">${b.isNew?`解锁图鉴 +${b.grant} 件`:`补货 +${b.grant} 件`}</span>`,o.appendChild(M),Lt(M,B*70);const m=b.design.rarity;m==="legendary"&&(u=!0),setTimeout(()=>{if(m==="legendary"?y.legendary():m==="epic"?y.rare():y.coin(),m==="epic"||m==="legendary"){const v=M.getBoundingClientRect();kt(v.left+v.width/2,v.top+v.height/2,[J[m].color,"#FFF"],10)}},B*70+100)}),setTimeout(()=>{document.getElementById("boxOk").style.visibility="visible",u&&y.legendary()},a.length*70+220)},900),document.getElementById("boxOk").onclick=()=>{y.buy(),i(),Ft()}}function Be(t,e="SSS",n=null){const a=w(),s=Ne(a,t,e);if(!s.ok)return L("钱不够啦，单抽需 ¥50","warn");n!=null&&a.shop[n]&&(a.shop[n].sold=!0);const{close:c}=yt(`
    <div class="boxstage">
      <div class="bm-modal-title">拆开神秘盲盒...</div>
      <div class="box-stage-wrap">
        <div class="box3d bm-mystery-3d-box" id="box3d">
          <div class="bm-modal-rect-box"></div>
        </div>
        <div class="box-reveal-banner" id="boxRevealBanner" style="display:none;"></div>
      </div>
      <div class="box-items" id="boxItems"></div>
      <button class="btn btn-primary" id="boxOk" style="visibility:hidden">收下并入库</button>
    </div>`,{closable:!1}),i=document.getElementById("box3d");setTimeout(()=>{i.classList.add("shaking"),y.tap()},60),setTimeout(()=>{i.classList.remove("shaking"),i.classList.add("opened");const r=i.getBoundingClientRect();kt(r.left+r.width/2,r.top+r.height/2,["#FFD98E","#FF7EB6","#7DE2D1","#C77DFF"],24),y.tear();const d=document.getElementById("boxRevealBanner");d&&(d.style.display="flex",d.innerHTML=`<span class="reveal-text">恭喜抽中 <b>${j(t,18)} ${X[t].name}盲盒</b>！</span>`);const l=document.getElementById("boxItems");s.items.forEach((o,u)=>{const b=document.createElement("div");b.className="box-item",b.innerHTML=`${Jt(o.design)}${o.isNew?'<span class="new-badge">NEW</span>':""}
        <span class="grant">${o.isNew?`解锁图鉴 +${o.grant} 件`:`补货 +${o.grant} 件`}</span>`,l.appendChild(b),Lt(b,u*160);const B=o.design.rarity;setTimeout(()=>{if(B==="legendary"?y.legendary():B==="epic"?y.rare():y.coin(),B==="epic"||B==="legendary"){const M=b.getBoundingClientRect();kt(M.left+M.width/2,M.top+M.height/2,[J[B].color,"#FFF"],12)}},u*160+200)}),setTimeout(()=>{document.getElementById("boxOk").style.visibility="visible",s.items.some(o=>o.design.rarity==="legendary")&&y.legendary()},s.items.length*160+300)},900),document.getElementById("boxOk").onclick=()=>{y.buy(),c(),Ft()}}function Xn(t){const e=w(),n=e.heldOrders&&e.heldOrders.length>0?`<div class="held-pack-notice"><b>有 ${e.heldOrders.length} 个保留订单</b> 待下一场开播：${e.heldOrders.map(a=>`${X[a.cat].name} ×${a.size}袋`).join("、")}，请记得装袋备货！</div>`:"";t.innerHTML=n+'<p class="pack-hint">每袋装 <b>1 件饰品 + 1 枚硬币</b>。自由匹配硬币。</p>'+lt.map(a=>{const s=e.packed[a]||[],c=me(e,a),i=T.cat===a;return`<div class="pack-card ${i?"open":""}">
        <button class="pack-head" data-cat="${a}">
          ${j(a,20)}<span>${X[a].name}</span>
          <em>库存 ${c} · 已装 ${s.length} 袋</em><i class="arr">${i?"▾":"▸"}</i>
        </button>
        ${Yn(e,a,i)}
        ${i?Un(e,a):""}
      </div>`}).join(""),t.querySelectorAll(".pack-head").forEach(a=>{a.onclick=()=>{y.tap();const s=a.dataset.cat,c=T.cat!==s;T.cat=T.cat===s?null:s,T.counts={},T.coins={},c&&(ct.designs=!0,ct.coins=!0),ut(t.closest(".tab-body"))}}),Vn(t),Jn(t)}function me(t,e){return H.filter(n=>n.cat===e).reduce((n,a)=>n+(t.stock[a.id]||0),0)}function Yn(t,e,n=!1){const a=t.packed[e]||[];if(a.length===0)return"";const s={},c={};for(const i of a)s[i.a]=(s[i.a]||0)+1,c[i.c]=(c[i.c]||0)+1;return`<div class="packed-sum ${n?"in-open":""}">
    <div class="ps-row ps-header">
      <span class="packed-sum-tag">已装袋</span>
      <button class="btn btn-mini btn-danger" data-unpack="${e}">撤回全部</button>
    </div>
    <div class="ps-row ps-designs">
      ${Object.entries(s).map(([i,r])=>`<span class="chip">${nt(i).name} ×${r}</span>`).join("")}
    </div>
    <div class="ps-row ps-coins">
      ${Object.entries(c).map(([i,r])=>`<span class="chip"><i class="coin-dot sm" style="--cc:${S[i].hex}">${S[i].name}</i> ×${r}</span>`).join("")}
    </div>
  </div>`}function Un(t,e){const n=H.filter(o=>o.cat===e&&o.rarity!=="limited"&&t.codex.includes(o.id)).map(o=>{const u=t.stock[o.id]||0,b=T.counts[o.id]||0;return`<div class="pack-row ${u===0?"off":""}">
        <span class="pr-ic" style="color:${J[o.rarity].color};display:inline-flex;align-items:center;">${j(o,16)}</span>
        <span class="pr-name">${o.name}</span>
        <span class="pr-stock">库存 ${u}</span>
        <div class="pr-step">
          <button class="cs-btn cs-btn-quick" data-zero="${o.id}" ${b===0?"disabled":""} title="一键清空"><<</button>
          <button class="cs-btn" data-dec="${o.id}" ${b===0?"disabled":""} title="减少1件"><</button>
          <b class="cs-n">${b}</b>
          <button class="cs-btn" data-inc="${o.id}" ${u===0||b>=u?"disabled":""} title="增加1件">></button>
          <button class="cs-btn cs-btn-quick" data-max="${o.id}" ${u===0||b>=u?"disabled":""} title="一键加满">>></button>
        </div>
      </div>`}).join(""),a=ce(),s=V.reduce((o,u)=>o+(T.coins[u]||0),0),c=V.map(o=>`
    <button class="coin-add" data-addcoin="${o}" ${a===0||s>=a?"disabled":""} title="点一下放一枚：${S[o].pair}">
      <i class="coin-dot" style="--cc:${S[o].hex}">${S[o].name}</i>
      <b>×${T.coins[o]||0}</b>
      <em>${S[o].pair}</em>
    </button>`).join(""),i=V.flatMap(o=>Array.from({length:T.coins[o]||0},()=>`<button class="coin-added" data-rmcoin="${o}" title="点一下取回一枚"><i class="coin-dot sm" style="--cc:${S[o].hex}">${S[o].name}</i></button>`)).join(""),r=a>0&&s===a,d=!ct.designs,l=!ct.coins;return`<div class="pack-panel">
    <div class="pp-sec ${d?"open":"collapsed"}">
      <div class="pp-sec-head" data-toggle-sec="designs">
        <div class="pp-sec-title">
          <i class="arr">${d?"▾":"▸"}</i>
          <span>选饰品</span>
          <small class="pp-sec-sub">（每款用 ± 调数量）</small>
        </div>
        <div class="pp-sec-meta">
          ${a?`<span class="pp-count">已选 ${a} 袋</span>`:'<span class="pp-sec-hint">点击折叠/展开</span>'}
        </div>
      </div>
      <div class="pp-sec-body">
        <div class="pack-rows">${n||'<span class="empty-hint">该品类还没有解锁款式，先去进货</span>'}</div>
        ${a?`<span class="pp-count pp-body-count">已选 ${a} 件饰品（共 ${a} 袋）</span>`:""}
      </div>
    </div>

    <div class="pp-sec ${l?"open":"collapsed"}">
      <div class="pp-sec-head" data-toggle-sec="coins">
        <div class="pp-sec-title">
          <i class="arr">${l?"▾":"▸"}</i>
          <span>配硬币</span>
          <small class="pp-sec-sub">（总数须 = ${a||0}）</small>
        </div>
        <div class="pp-sec-meta">
          <span class="pp-count ${s===a&&a>0?"":"warn"}">硬币 ${s} / ${a}</span>
          <button class="btn btn-mini" data-act="autocoin" ${a===0?"disabled":""}>自动配币</button>
        </div>
      </div>
      <div class="pp-sec-body">
        <div class="coin-adds">${c}</div>
        <div class="coin-added-row">${i||'<span class="empty-hint">还没放硬币，点上面加入</span>'}</div>
        <div class="coin-summary-foot">
          <span class="pp-count ${s===a&&a>0?"":"warn"}">已配硬币：${s} / ${a} 枚</span>
        </div>
      </div>
    </div>

    <div class="pp-actions">
      <button class="btn btn-ghost" data-act="autofill" data-cat="${e}" ${me(t,e)===0?"disabled":""}>一键装袋</button>
      <button class="btn btn-primary" data-act="confirm" data-cat="${e}" ${r?"":"disabled"}>确认装袋</button>
    </div>
  </div>`}function ce(){return Object.values(T.counts).reduce((t,e)=>t+e,0)}function Wn(){const t=[];for(const[e,n]of Object.entries(T.counts))for(let a=0;a<n;a++)t.push(e);return t}function Vn(t){t.querySelectorAll("[data-toggle-sec]").forEach(s=>{s.onclick=c=>{if(c.target.closest('[data-act="autocoin"]'))return;const i=s.dataset.toggleSec;ct[i]=!ct[i],y.tap(),ut(t.closest(".tab-body"))}}),t.querySelectorAll("[data-inc]").forEach(s=>{s.onclick=()=>{const c=w(),i=s.dataset.inc,r=(T.counts[i]||0)+1;if(r>(c.stock[i]||0))return L("该款式库存不够啦","warn");y.tap(),T.counts[i]=r,ut(t.closest(".tab-body"))}}),t.querySelectorAll("[data-dec]").forEach(s=>{s.onclick=()=>{y.tap();const c=s.dataset.dec;T.counts[c]=Math.max(0,(T.counts[c]||0)-1),T.counts[c]===0&&delete T.counts[c],ut(t.closest(".tab-body"))}}),t.querySelectorAll("[data-zero]").forEach(s=>{s.onclick=()=>{y.tap();const c=s.dataset.zero;delete T.counts[c],ut(t.closest(".tab-body"))}}),t.querySelectorAll("[data-max]").forEach(s=>{s.onclick=()=>{const c=w(),i=s.dataset.max,r=c.stock[i]||0;r<=0||(y.tap(),T.counts[i]=r,ut(t.closest(".tab-body")))}}),t.querySelectorAll("[data-addcoin]").forEach(s=>{s.onclick=()=>{const c=s.dataset.addcoin,i=ce();if(V.reduce((d,l)=>d+(T.coins[l]||0),0)>=i)return L("硬币总数要等于袋数","warn");y.coin(),T.coins[c]=(T.coins[c]||0)+1,ut(t.closest(".tab-body"))}}),t.querySelectorAll("[data-rmcoin]").forEach(s=>{s.onclick=()=>{y.tap();const c=s.dataset.rmcoin;T.coins[c]=Math.max(0,(T.coins[c]||0)-1),T.coins[c]===0&&delete T.coins[c],ut(t.closest(".tab-body"))}});const e=t.querySelector('[data-act="autocoin"]');e&&(e.onclick=s=>{s.stopPropagation(),y.tap(),T.coins=Te(ce()),ut(t.closest(".tab-body"))});const n=t.querySelector('[data-act="autofill"]');n&&(n.onclick=()=>{const s=w(),c=n.dataset.cat,i=hn(s,c,me(s,c)),r=Te(i.length);if(!$e(s,c,i,r).ok)return L("装袋失败","warn");Ee(c,i.length,i,r),T.counts={},T.coins={},ct.designs=!0,ct.coins=!0});const a=t.querySelector('[data-act="confirm"]');a&&(a.onclick=()=>{const s=w(),c=a.dataset.cat,i=Wn(),r=et({},T.coins),d=$e(s,c,i,r);if(!d.ok)return d.reason==="coinSum"?L("硬币总数要等于袋数","warn"):L("库存不足","warn");Ee(c,i.length,i,r),T.counts={},T.coins={},ct.designs=!0,ct.coins=!0})}function Ee(t,e,n=[],a={}){var Y,Q,I;const s=w(),c=n&&n[0]&&nt(n[0])||H.find(h=>h.cat===t&&h.rarity!=="limited"&&s.codex.includes(h.id))||H.find(h=>h.cat===t)||{name:((Y=X[t])==null?void 0:Y.name)||"精美饰品",cat:t,rarity:"rare"};let i=Object.keys(a).find(h=>a[h]>0)||((Q=s.trend)==null?void 0:Q.lucky)||"gold";const r=S[i]||S.gold,{close:d}=yt(`
    <div class="pack-interactive-stage">
      <div class="pack-header">
        <b class="pack-title" id="packTitle">装袋</b>
        <span class="pack-num">${X[t].name}盲袋 × ${e}</span>
        <p class="pack-guide-hint" id="packGuideHint">拖动饰品与硬币放入自封袋</p>
      </div>

      <div class="pack-workarea" id="packWorkarea">
        <!-- 弹窗关闭前直接在中央弹出的装袋成功浮层 -->
        <div class="pack-success-popup" id="packSuccessPopup">装袋成功！</div>

        <!-- 左边：咬口式彩色自封盲袋 -->
        <div class="ziplock-bag-col" id="packBagDropzone">
          <div class="ziplock-pack-bag pack-anim" id="packBag">
            <!-- 顶部挂孔与撕裂凹槽 -->
            <div class="zpb-top-rim">
              <div class="zpb-notch left"></div>
              <div class="zpb-hang-hole"></div>
              <div class="zpb-notch right"></div>
            </div>

            <!-- 咬口自封条轨道（实色银色线条互动滑动条） -->
            <div class="zpb-track-container" id="zipTrackContainer">
              <div class="zpb-track-groove">
                <div class="zpb-track-sealed" id="zipTrackSealed"></div>
              </div>
              <div class="zpb-slider-thumb" id="zipSliderThumb">
                <div class="zpb-thumb-grip">
                  <svg class="zpb-thumb-svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="8 5 15 12 8 19"></polyline>
                  </svg>
                </div>
              </div>
              <div class="zpb-slide-hint" id="zbSlideHint">
                
                <span class="zpb-hint-text">从左向右滑动封口</span>
              </div>
            </div>

            <!-- 半透明彩色袋身 -->
            <div class="zpb-body" id="zpbBody">
              <div class="zpb-weld left"></div>
              <div class="zpb-weld right"></div>
              <div class="zpb-weld bottom"></div>

              <!-- 品类中央印花 -->
              <div class="zpb-watermark" id="zpbWatermark">
                <span class="zpb-wm-ic">${j(t,48)}</span>
              </div>
              <div class="zpb-sheen"></div>
            </div>
          </div>
        </div>

        <!-- 右边：上面饰品图案（透明背景），下面硬币（透明背景） -->
        <div class="pack-items-col" id="packItemsCol">
          <!-- 饰品图案（透明背景） -->
          <div class="pack-drag-item" id="dragJewel" data-type="jewel" title="拖动或点击装入饰品">
            <div class="pack-jewel-preview" style="color: ${((I=J[c.rarity])==null?void 0:I.color)||"var(--pink-deep)"};">
              ${j(c,52)}
            </div>
          </div>

          <!-- 下面硬币（透明背景） -->
          <div class="pack-drag-item" id="dragCoin" data-type="coin" data-key="${i}" title="拖动或点击装入硬币">
            <span class="pack-coin-preview ${i==="blue"?"coin-is-blue":""}" style="--cc:${r.hex}">
              <span class="pack-coin-tint"></span>
            </span>
          </div>
        </div>
      </div>

      <button class="btn btn-primary" id="packOk" style="display:none; margin-top: 14px;">收下</button>
    </div>`,{closable:!1}),l=document.getElementById("packBagDropzone"),o=document.getElementById("packBag"),u=document.getElementById("packTitle"),b=document.getElementById("packGuideHint"),B=document.getElementById("packStatusTag"),M=document.getElementById("packWorkarea"),m=document.getElementById("dragJewel"),v=document.getElementById("dragCoin");document.getElementById("packOk");const g=document.getElementById("zipTrackContainer"),f=document.getElementById("zipSliderThumb"),$=document.getElementById("zipTrackSealed");let P=!1,C=!1,R=!1,G=!1;function it(h){h==="jewel"&&(P=!0),h==="coin"&&(C=!0);const D=(P?1:0)+(C?1:0);D===1?(B&&(B.textContent="已装入 (1/2)"),b.textContent=P?"太棒了！接着把硬币装入袋中":"太棒了！接着把饰品装入袋中"):D===2&&!R&&(R=!0,B&&(B.textContent="待封口",B.className="pack-status-tag ready-seal"),b.textContent="👉 物品已装好！从左向右滑动封口",u.textContent="滑动咬口封袋",setTimeout(()=>{M.classList.add("center-bag"),g&&g.classList.add("ready-to-seal"),y.tap()},320))}function rt(){if(!g||!f)return;const h=()=>{const N=g.getBoundingClientRect(),q=f.offsetWidth||32,ot=Math.max(10,N.width-q);return{rect:N,thumbW:q,maxDist:ot}};let D=!1,F=-1,_=0,K=0,Z=0,x=null;function dt(){if(G)return;if(G=!0,D=!1,_=1,x!==null){try{g.releasePointerCapture(x)}catch(ot){}x=null}const{maxDist:N}=h();f.style.transition="left 0.12s cubic-bezier(0.18, 1, 0.3, 1)",$.style.transition="width 0.12s cubic-bezier(0.18, 1, 0.3, 1)",f.style.left=`${N}px`,$.style.width="100%",g.classList.remove("sliding"),g.classList.add("sealed-done"),o.classList.add("sealed-done"),y.seal?y.seal():y.buy();const q=document.getElementById("packSuccessPopup");q&&q.classList.add("show"),u.textContent="🎉 装袋成功！",b.textContent="🎉 装袋成功！已放入库房",B&&(B.textContent="已封装",B.className="pack-status-tag ready-seal"),L("🎉 装袋成功！"),setTimeout(()=>{d(),Ft()},620)}const U=N=>{if(G)return;const{maxDist:q}=h(),ot=N-K,Bt=Math.max(0,Math.min(q,Z+ot));_=q>0?Bt/q:1,f.style.left=`${Bt}px`,$.style.width=`${_*100}%`;const Nt=Math.floor(_*6);Nt!==F&&(F=Nt,y.zip?y.zip():y.tap()),(_>=.82||Bt>=q-16)&&dt()},St=N=>{if(!R||G)return;D=!0,F=-1,x=N.pointerId;try{g.setPointerCapture(x)}catch(ra){}const{rect:q,thumbW:ot,maxDist:Bt}=h(),Nt=N.clientX-q.left;K=N.clientX;const ye=parseFloat(f.style.left)||0;Nt>ye+ot+10?Z=Math.max(0,Math.min(Bt,Nt-ot/2)):Z=ye,g.classList.add("sliding"),f.style.transition="none",$.style.transition="none",U(N.clientX)},A=N=>{!D||G||U(N.clientX)},vt=N=>{if(!(!D||G)){if(D=!1,x!==null){try{g.releasePointerCapture(x)}catch(q){}x=null}g.classList.remove("sliding"),_>=.75?dt():(_=0,f.style.transition="left 0.25s cubic-bezier(0.2, 0.9, 0.3, 1)",$.style.transition="width 0.25s cubic-bezier(0.2, 0.9, 0.3, 1)",f.style.left="0px",$.style.width="0%",b.textContent="从左向右滑动封口哦～ 👉",setTimeout(()=>{G||(f.style.transition="",$.style.transition="")},260))}};g.addEventListener("pointerdown",St),g.addEventListener("pointermove",A),g.addEventListener("pointerup",vt),g.addEventListener("pointercancel",vt)}rt();function k(h,D,F){h.dataset.packed="true",h.classList.remove("dragging"),h.style.pointerEvents="none",h.style.opacity="0";const _=o.getBoundingClientRect(),K=_.left+_.width/2,Z=_.top+_.height/2+10,x=h.cloneNode(!0);x.id="",x.style.position="fixed",x.style.left=`${F.left}px`,x.style.top=`${F.top}px`,x.style.width=`${F.width}px`,x.style.height=`${F.height}px`,x.style.zIndex="9999",x.style.pointerEvents="none",x.style.margin="0",x.style.opacity="1",x.style.transform="scale(1)",x.style.transition="transform 0.28s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.24s ease-in",document.body.appendChild(x);const dt=K-(F.left+F.width/2),U=Z-(F.top+F.height/2);requestAnimationFrame(()=>{x.style.transform=`translate(${dt}px, ${U}px) scale(0.2)`,x.style.opacity="0"}),setTimeout(()=>{x.remove(),D==="coin"?y.coin():y.tap(),l.classList.add("swallow"),setTimeout(()=>l.classList.remove("swallow"),300),it(D)},260)}function E(h,D){let F=!1,_=!1,K=0,Z=0,x=null;const dt=A=>{if(!(h.dataset.packed==="true"||R)){F=!0,_=!1,K=A.clientX,Z=A.clientY,x=A.pointerId;try{h.setPointerCapture(x)}catch(vt){}h.style.transition="none"}},U=A=>{if(!F||A.pointerId!==x)return;const vt=A.clientX-K,N=A.clientY-Z;if(!_&&Math.hypot(vt,N)>4&&(_=!0,h.classList.add("dragging")),_){h.style.transform=`translate(${vt}px, ${N}px) scale(1.15)`;const q=o.getBoundingClientRect(),ot=A.clientX>=q.left-20&&A.clientX<=q.right+20&&A.clientY>=q.top-20&&A.clientY<=q.bottom+20;l.classList.toggle("drag-over",ot)}},St=A=>{if(!F||A.pointerId!==x)return;F=!1;try{h.releasePointerCapture(x)}catch(Bt){}l.classList.remove("drag-over");const vt=h.getBoundingClientRect(),N=o.getBoundingClientRect(),q=A.clientX>=N.left-25&&A.clientX<=N.right+25&&A.clientY>=N.top-25&&A.clientY<=N.bottom+25,ot=!_||Math.hypot(A.clientX-K,A.clientY-Z)<6;q||ot?k(h,D,vt):(h.classList.remove("dragging"),h.style.transition="transform 0.25s cubic-bezier(0.2, 1.2, 0.4, 1)",h.style.transform="")};h.addEventListener("pointerdown",dt),h.addEventListener("pointermove",U),h.addEventListener("pointerup",St),h.addEventListener("pointercancel",St)}E(m,"jewel"),E(v,"coin")}function Te(t){const e={};V.forEach(a=>{e[a]=0});const n=["red","gold","blue","purple","green"];for(let a=0;a<t;a++)a===0&&Math.random()<.25?e.secret_s++:a===1&&Math.random()<.15?e.secret_b++:e[n[a%n.length]]++;return e}function Jn(t){t.querySelectorAll("[data-unpack]").forEach(e=>{e.onclick=()=>{const n=w();bn(n,e.dataset.unpack),y.tap(),Ft()}})}function Kn(t){const e=w();t.innerHTML=lt.map(n=>{const a=H.filter(c=>c.cat===n),s=a.filter(c=>e.codex.includes(c.id)||c.rarity==="limited"&&e.vault.some(i=>i.designId===c.id)).length;return`<div class="codex-cat">
      <div class="codex-head">${j(n,18)}<span>${X[n].name}</span><em>${s}/${a.length}</em></div>
      <div class="codex-grid">
        ${a.map(c=>{const i=e.codex.includes(c.id);if(c.rarity==="limited"){if(!i)return`<div class="dcard rc-limited locked"><div class="dcard-ic">${j(c,24)}</div><div class="dcard-nm">？？？</div><div class="dcard-sub">暂未开放</div></div>`;const r=e.vault.filter(d=>d.designId===c.id).length;return Jt(c,{sub:`限定 · 待售 ${r}`})}return Jt(c,{locked:!i,count:i?e.stock[c.id]||0:null})}).join("")}
      </div>
    </div>`}).join("")}const Qn=()=>document.getElementById("app"),Zn={ring:'<circle cx="12" cy="14.5" r="5.5"/><path d="M9.5 6.5 12 4l2.5 2.5L12 9z"/>',necklace:'<path d="M4.5 4c.8 6.5 3.6 9.5 7.5 9.5S18.7 10.5 19.5 4"/><circle cx="12" cy="17" r="2.4"/>',bracelet:'<circle cx="12" cy="12" r="7" stroke-dasharray="2.4 3"/><circle cx="12" cy="5" r="1.7"/>',earring:'<path d="M12 3v3.5"/><circle cx="12" cy="8.5" r="1.4"/><path d="M12 11c-2.4 1.6-3.4 3.4-3.4 4.9a3.4 3.4 0 0 0 6.8 0c0-1.5-1-3.3-3.4-4.9z"/>'},ta={ring:{common:'<circle cx="12" cy="14" r="5.5"/><rect x="10" y="7" width="4" height="2" rx="0.5"/>',rare:'<circle cx="12" cy="14.5" r="5.5"/><path d="M9.5 6.5 12 4l2.5 2.5L12 9z"/><path d="M9.5 6.5h5"/>',epic:'<circle cx="12" cy="15" r="5"/><path d="M8 7.5 12 3l4 4.5-4 3.5z"/><line x1="8" y1="7.5" x2="16" y2="7.5"/><line x1="12" y1="3" x2="12" y2="11"/><path d="M5.5 5.5 7 7m11.5-1.5L17 7"/>',legendary:'<circle cx="12" cy="15.5" r="4.8"/><path d="M7 8.5 9 5.5l3-2.5 3 2.5 2 3-5 3.5z"/><path d="M9 5.5h6"/><circle cx="12" cy="7.5" r="1.2" fill="currentColor"/><path d="M4 10.5l2.5-1m13.5 1-2.5-1"/>',limited:'<circle cx="12" cy="15" r="5"/><path d="M12 2l1.8 3.2L17 6l-3.2 1.8L12 11l-1.8-3.2L7 6l3.2-.8z"/><circle cx="12" cy="6" r="1.2" fill="currentColor"/><path d="M4.5 9.5l2 1m13-1-2 1"/>'},necklace:{common:'<path d="M4.5 5c.8 6 3.5 9 7.5 9s6.7-3 7.5-9"/><circle cx="12" cy="17" r="2.2"/><path d="M12 14v1"/>',rare:'<path d="M4.5 4.5c.8 6.5 3.6 9.5 7.5 9.5s6.7-3 7.5-9.5"/><path d="M12 14v1.5"/><path d="M12 15.5c-2 2-2 3.5-1 4.5 1 1 3 1 4 0 1-1 1-2.5-1-4.5z"/><circle cx="12" cy="18" r="0.8" fill="currentColor"/>',epic:'<path d="M5 4c.6 5 3.2 8 7 8s6.4-3 7-8"/><path d="M7.5 4c.5 6 2.2 9.5 4.5 9.5s4-3.5 4.5-9.5"/><path d="M12 13.5v2"/><path d="M12 15.5l2.2 2.2-2.2 3.3-2.2-3.3z"/><path d="M10 17.7h4"/>',legendary:'<path d="M4 4c1 7 4 10.5 8 10.5s7-3.5 8-10.5"/><path d="M12 14.5v1.5"/><path d="M8.5 18l3.5-3 3.5 3-3.5 4.5z"/><circle cx="12" cy="18" r="1.3" fill="currentColor"/><circle cx="7" cy="10" r="1.2" fill="currentColor"/><circle cx="17" cy="10" r="1.2" fill="currentColor"/>',limited:'<path d="M4 4.5c.8 6.5 3.6 9.5 8 9.5s7.2-3 8-9.5"/><path d="M12 14v1.5"/><path d="M8.5 19c0-2.8 3.5-6 3.5-6s3.5 3.2 3.5 6a3.5 3.5 0 0 1-7 0z"/><circle cx="12" cy="18.5" r="1.2" fill="currentColor"/><path d="M3.5 12l2 1m15-1-2 1M12 21.5v2"/>'},bracelet:{common:'<circle cx="12" cy="12" r="7" stroke-dasharray="2 2.5"/><circle cx="12" cy="5" r="1.6"/>',rare:'<circle cx="12" cy="11.5" r="6.8"/><path d="M12 18.3v2.2"/><circle cx="12" cy="22" r="1.5"/><path d="M6 9.5l-1.5-1m13.5 1 1.5-1"/>',epic:'<ellipse cx="12" cy="12" rx="7.5" ry="5.5"/><ellipse cx="12" cy="12" rx="5.5" ry="7.5" stroke-dasharray="3 2"/><circle cx="12" cy="4.5" r="1.6" fill="currentColor"/><circle cx="12" cy="19.5" r="1.6" fill="currentColor"/><path d="M4.5 12h2m11 0h2"/>',legendary:'<path d="M6.5 15.5A7 7 0 1 1 17.5 15.5"/><path d="M5.5 14l2 2-2 2m13-4-2 2 2 2"/><circle cx="12" cy="5" r="2.2"/><circle cx="12" cy="5" r="0.9" fill="currentColor"/><path d="M9 7.5 7.5 9m7.5-1.5 1.5 1.5"/>',limited:'<circle cx="12" cy="12" r="7"/><path d="M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/><path d="M12 10.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/><path d="M5 7.5l2 1m10-1-2 1M5 16.5l2-1m10 1-2-1"/>'},earring:{common:'<path d="M12 3.5v4"/><circle cx="12" cy="7.5" r="1.5"/><path d="M12 9v3"/><circle cx="12" cy="15" r="3"/>',rare:'<path d="M12 3v3.5"/><circle cx="12" cy="8" r="1.5"/><path d="M12 10c-2.5 1.8-3.5 3.5-3.5 5.2a3.5 3.5 0 0 0 7 0c0-1.7-1-3.4-3.5-5.2z"/><circle cx="12" cy="14.5" r="1" fill="currentColor"/>',epic:'<path d="M12 3v2.5"/><circle cx="12" cy="7" r="1.3"/><path d="M12 8.5 8.5 13l3.5 4.5 3.5-4.5z"/><path d="M8.5 13h7"/><path d="M12 17.5v3.5"/><circle cx="12" cy="22" r="1" fill="currentColor"/>',legendary:'<path d="M12 3a2.5 2.5 0 0 0-2.5 2.5v2a2.5 2.5 0 0 0 5 0v-2A2.5 2.5 0 0 0 12 3z"/><circle cx="12" cy="11.5" r="1.2" fill="currentColor"/><path d="M7 14.5l5-2 5 2-2.5 5.5-2.5 2.5-2.5-2.5z"/><path d="M9.5 16.5h5"/><path d="M12 18.5v3.5"/>',limited:'<path d="M12 3v3"/><circle cx="12" cy="8" r="1.5"/><path d="M12 10.5v1.5"/><path d="M12 12l2.8 2.8-2.8 4.2-2.8-4.2z"/><path d="M9.2 14.8h5.6"/><path d="M5.5 15l2 .5m9-.5 2 .5"/><circle cx="12" cy="15" r="1" fill="currentColor"/>'}};function j(t,e=22,n=null){var i;let a=t,s=n;typeof t=="object"&&t!==null&&(a=t.cat,s=s||t.rarity);const c=s&&((i=ta[a])==null?void 0:i[s])||Zn[a]||"";return`<svg viewBox="0 0 24 24" width="${e}" height="${e}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${c}</svg>`}function Jt(t,{count:e,locked:n,sub:a}={}){const s=J[t.rarity],c=n?"？？？":t.name,i=a!=null?a:`${s.name}${e!=null?` · 库存 ${e}`:""}`;return`<div class="dcard rc-${t.rarity}${n?" locked":""}">
    <div class="dcard-ic">${j(t,24)}</div>
    <div class="dcard-nm">${c}</div>
    <div class="dcard-sub">${i}</div>
  </div>`}function L(t,e="info"){const n=document.createElement("div");n.className=`toast toast-${e}`,n.textContent=t,document.body.appendChild(n),setTimeout(()=>n.classList.add("show"),10),setTimeout(()=>{n.classList.remove("show"),setTimeout(()=>n.remove(),300)},1800)}function yt(t,{closable:e=!0}={}){const n=document.createElement("div");n.className="modal-mask",n.innerHTML=`<div class="modal">${t}</div>`,document.body.appendChild(n),requestAnimationFrame(()=>n.classList.add("show"));const a=()=>{n.classList.remove("show"),setTimeout(()=>n.remove(),220)};return e&&n.addEventListener("click",s=>{s.target===n&&a()}),{el:n,root:n,close:a}}function Ce(t,e=16){return t?`<svg viewBox="0 0 24 24" width="${e}" height="${e}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" y1="9" x2="16" y2="15"/><line x1="16" y1="9" x2="22" y2="15"/></svg>`:`<svg viewBox="0 0 24 24" width="${e}" height="${e}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>`}function ea(t){const e=Kt(t.fans),n=Ve(t.fans),a=document.createElement("header");return a.className="topbar",a.innerHTML=`
    <div class="tb-left">
      <span class="tb-day">第 ${t.day} 天</span>
      <span class="tb-tier">${e.name}</span>
    </div>
    <div class="tb-right">
      <span class="tb-money">¥ <b>${t.money}</b></span>
      <span class="tb-fans" title="${n?`距${n.name}还差 ${n.fans-t.fans} 粉`:"已满级"}">粉丝 <b>${t.fans}</b></span>
      <button class="tb-btn" data-act="mute" title="音效">${Ce(t.muted)}</button>
      <button class="tb-btn" data-act="help" title="玩法">?</button>
    </div>`,a.querySelector('[data-act="mute"]').onclick=function(){const s=!w().muted;ze(s),bt({muted:s}),this.innerHTML=Ce(s),y.tap()},a.querySelector('[data-act="help"]').onclick=()=>na(),a}function xt(t){const e=document.querySelector(".tb-money b"),n=document.querySelector(".tb-fans b");e&&(e.textContent=t.money),n&&(n.textContent=t.fans)}function na(){y.tap(),yt(`
    <h3 class="m-title">玩法说明</h3>
    <div class="help-body">
      <p><b>商店</b>：商店每日能买10个盲盒 （可花钱更新次数）。开出新款式解锁图鉴并入库 10 件；已有款式的数量由饰品等级而决定。</p>
      <p><b>装袋</b>：每个盲袋里面有 1 件饰品 + 1 枚硬币，单色硬币不超过总数的40%。可自动或者手动装袋。</p>
      <p><b>直播</b>：粉丝数量制定订单数量。拆袋时——拆到<b>幸运色</b>硬币多拆一袋；同色硬币<b>凑成对</b>触发「对对碰」：多拆一袋 + 增效。木盘全部碰空还有「清盘」奖励三袋。</p>
      <p><b>投流</b>：粉丝数到达10，000自动解锁。每天玩家都能投流一次，每次花费¥200。 投流之后会增加直播热度，直播热度超过粉丝数的20%时系统额外追加1笔推流订单，此订单最终收益享有双倍结算。</p>
      <p><b>奶一口</b>：玩家可以在每单最后选择给单主奶一口（增加一袋）。</p>
      <p><b>随机事件</b>：每场直播会有几率触发随机事件，分为涨粉或跌粉事件</p>
      <p><b>下播</b>：按订单结算收入，观众评价影响粉丝加成。当日风向品类订单收入 + 50%。</p>
    </div>
    <button class="btn btn-primary m-close">知道了</button>
  `,{closable:!0}).el.querySelector(".m-close").onclick=function(){this.closest(".modal-mask").classList.remove("show"),setTimeout(()=>this.closest(".modal-mask").remove(),220)}}function aa(t){const e=w(),n=Object.values(e.packed||{}).some(c=>Array.isArray(c)&&c.length>0),a=Object.values(e.stock||{}).some(c=>typeof c=="number"&&c>0),s=!!e.hasSavedData||e.day>1||e.money!==1e3||e.codex&&e.codex.length>0||n||a||e.heldOrders&&e.heldOrders.length>0||e.vault&&e.vault.length>0||e.gems&&e.gems.length>0&&e.gems.some(c=>c.bought);t.innerHTML=`
    <div class="intro">
      <div class="intro-spot"></div>
      <div class="intro-badge">饰品盲袋 · 经营直播</div>
      <h1 class="intro-title">今夜拆什么</h1>
      <p class="intro-sub">直播饰品对对碰</p>
      <div class="intro-actions">
        ${s?'<button class="btn btn-primary btn-big" data-act="continue">继续经营</button><button class="btn btn-ghost" data-act="new">重新开店</button>':'<button class="btn btn-primary btn-big" data-act="new">开业！</button>'}
      </div>
      <div class="intro-tips">
        <span>快乐拆拆</span><span>对对碰</span>
      </div>
    </div>`,t.querySelectorAll("[data-act]").forEach(c=>{c.onclick=()=>Et(null,null,function*(){if(y.buy(),c.dataset.act==="new"){yield pn();const i=Pe();de(i),i.shop=Pt(),i.trend.style=Ht(i,i.trend.cat),bt(pt(et({},i),{screen:"day",dayTab:"shop"}))}else{const i=w();(!Array.isArray(i.shop)||i.shop.length!==10)&&(i.shop=Pt()),i.trend.style||(i.trend.style=Ht(i,i.trend.cat)),bt({screen:"day",dayTab:"shop"})}st(re(w()))})})}let Yt="";function ie(){const t=w();En();const e=Qn();e.innerHTML="",e.appendChild(ea(t));const n=document.createElement("section");n.className=`screen sc-${t.screen}`,e.appendChild(n),t.screen==="intro"?aa(n):t.screen==="day"?jn(n):t.screen==="live"?Cn(n):t.screen==="settle"&&qn(n)}function Ft(){Yt="",ie(),w().screen==="day"&&st()}function sa(){rn(()=>{const t=w(),e=`${t.screen}:${t.dayTab}`;e!==Yt&&(Yt=e,ie())}),window.addEventListener("contextmenu",t=>{t.preventDefault()}),window.addEventListener("beforeunload",()=>{st()}),window.addEventListener("pagehide",()=>{st()}),Yt="",ie()}function ca(t){var n,a,s,c,i,r,d;const e=(l,o)=>Number.isFinite(l)?l:o;if(t.money=e(t.money,1e3),t.fans=e(t.fans,100),t.day=e(t.day,1),t.streamsLeft=e(t.streamsLeft,jt),t.trend={cat:((n=t.trend)==null?void 0:n.cat)||"ring",lucky:((a=t.trend)==null?void 0:a.lucky)||"red",style:(c=(s=t.trend)==null?void 0:s.style)!=null?c:null,saleStyle:(r=(i=t.trend)==null?void 0:i.saleStyle)!=null?r:null,saleDiscount:((d=t.trend)==null?void 0:d.saleDiscount)||.5},t.trend.style||(t.trend.style=Ht(t,t.trend.cat)),t.trend.saleStyle||(t.trend.saleStyle=pe(t,t.trend.cat,t.trend.style)),Array.isArray(t.codex)||(t.codex=[]),Array.isArray(t.codexBonus)||(t.codexBonus=[]),Array.isArray(t.vault)||(t.vault=[]),Array.isArray(t.gems)||(t.gems=[]),Array.isArray(t.shop)&&t.shop.forEach(l=>{l&&(l.tier="SSS")}),(typeof t.stock!="object"||!t.stock)&&(t.stock={}),typeof t.packed!="object"||!t.packed)t.packed={};else for(const l of Object.keys(t.packed))if(Array.isArray(t.packed[l])){for(let o=0;o<t.packed[l].length;o++){const u=t.packed[l][o],b=nt(u.a);u.r=Dt(b==null?void 0:b.rarity)}for(let o=t.packed[l].length-1;o>0;o--){const u=Math.floor(Math.random()*(o+1));[t.packed[l][o],t.packed[l][u]]=[t.packed[l][u],t.packed[l][o]]}}return Array.isArray(t.heldOrders)||(t.heldOrders=[]),t.adBoostUsedToday=!!t.adBoostUsedToday,t}function ia(){return Et(this,null,function*(){var c,i;let t=null;const e=typeof GameSDK!="undefined"?GameSDK:typeof window!="undefined"?window.GameSDK:null;if(e!=null&&e.init)try{t=yield e.init(),console.log("[game] ready, gameId =",(c=t==null?void 0:t.context)==null?void 0:c.gameId)}catch(r){console.warn("[game] SDK init failed, running in local fallback",r)}else typeof window!="undefined"&&((i=window.sdk)!=null&&i.storage)&&(t=window.sdk);ln(t);let n=Pe();const a=yield dn(),s=!!(a&&typeof a.day=="number");s&&(n=pt(et(et({},n),a),{screen:"intro",stats:null,hasSavedData:!0}),n=ca(n)),(!Array.isArray(n.gems)||n.gems.length===0)&&de(n),(!Array.isArray(n.shop)||n.shop.length!==10)&&(n.shop=Pt()),ze(!!n.muted),cn(n),s&&st(re(w())),sa()})}ia();
